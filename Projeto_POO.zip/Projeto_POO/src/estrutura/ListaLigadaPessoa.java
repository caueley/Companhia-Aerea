package estrutura;

import usuario.Pessoa;
import exceptions.NaoCadastradoException;
import javax.swing.JOptionPane;
import exceptions.RepetidoException;

public class ListaLigadaPessoa {
	private class LinkedNode {
		private Pessoa data;
		private LinkedNode next;
	}
	
	private LinkedNode first;
	
	public void adicionaPessoa(Pessoa pessoa) throws Exception {
		LinkedNode novaPessoa = new LinkedNode();
		novaPessoa.data = pessoa;
		novaPessoa.next = null;
		
		if(first == null) {
			novaPessoa.data.setId(1);
			this.first = novaPessoa;
		} else {
			LinkedNode anterior = null;
			LinkedNode atual = first;
			
			while(atual != null) {
				if(novaPessoa.data.getCpf().equals(atual.data.getCpf())) {
					throw new RepetidoException("CPF");
				}
				if(novaPessoa.data.getUsuario().equals(atual.data.getUsuario())) {
					throw new RepetidoException("usu�rio");
				}
				anterior = atual;
				atual = atual.next;
			}
			novaPessoa.data.setId(tamanhoDaLista()+1);
			anterior.next = novaPessoa;
		}
	}
	
	public void removePessoa(int id) throws Exception {
		LinkedNode anterior = null;
		LinkedNode atual = first;
		
		while(atual != null && atual.data.getId() != id) {
			anterior = atual;
			atual = atual.next;
		}
		
		if(atual != null) {
			if(anterior == null) {
				first = atual.next;
				JOptionPane.showMessageDialog(null, "Usu�rio Exclu�do com Sucesso!");
			} else {
				anterior.next = atual.next;
			}
		} else {
			throw new NaoCadastradoException("pessoa");
		}
	}
	
	public String listarPessoas() throws Exception {
		LinkedNode node = first;
		String lista = null;
		while(node != null) {
				if(node == first) {
					lista = "Clientes:";
				}
				lista += "\n		ID: " + node.data.getId() + "		Nome: " + node.data.getNomeCompleto() + 
						"		CPF: " + node.data.getCpf();
		}
		if(lista != null) {
			return lista;
		} else {
			throw new NaoCadastradoException("pessoa");
		}
	}
	
	public int tamanhoDaLista() {
		LinkedNode node = first;
		int cont = 0;
		while(node != null) {
			node = node.next;
			cont++;
		}
		return cont;
	}
	
	public Pessoa verificaLogin(String usuario, String senha) {
		LinkedNode node = first;
		while(node != null && !node.data.getUsuario().equals(usuario)) {
			node = node.next;
		}
		
		if(node == null) {
			return null;
		} else {
			if(node.data.getSenha().equals(senha)) {
				return node.data;
			}
			else {
				return null;
			}
		}
	}

}
