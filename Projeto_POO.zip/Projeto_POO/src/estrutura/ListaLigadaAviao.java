package estrutura;

import companhia.Aviao;
import javax.swing.JOptionPane;
import exceptions.NaoCadastradoException;

public class ListaLigadaAviao {
	private class LinkedNode {
		private Aviao data;
		private LinkedNode next;
	}

	private LinkedNode first;

	public void adicionaAviao(Aviao aviao) throws Exception {
		LinkedNode novoAviao = new LinkedNode();
		novoAviao.data = aviao;
		novoAviao.next = null;

		if(first == null) {
			novoAviao.data.setId(1);
			this.first = novoAviao;
		} else {
			LinkedNode anterior = null;
			LinkedNode atual = first;

			while(atual != null) {
				anterior = atual;
				atual = atual.next;
			}
			novoAviao.data.setId(tamanhoDaLista()+1);
			anterior.next = novoAviao;
		}
	}

	public void removePessoa(int id) throws Exception {
		LinkedNode anterior = null;
		LinkedNode atual = first;

		while(atual != null && atual.data.getId() != id) {
			anterior = atual;
			atual = atual.next;
		}

		if(atual != null) {
			if(anterior == null) {
				first = atual.next;
			} else {
				anterior.next = atual.next;
			}
			JOptionPane.showMessageDialog(null, "Avi�o Exclu�do com Sucesso!");
		} else {
			throw new NaoCadastradoException("avi�o");
		}
	}

	public String listarAvioes() throws Exception {
		LinkedNode node = first;
		String lista = null;
		while(node != null) {
			lista += "\n" + node.data.info();
		}
		if(lista != null) {
			return lista;
		} else {
			throw new NaoCadastradoException("avi�o");
		}
	}

	public int tamanhoDaLista() {
		LinkedNode node = first;
		int cont = 0;
		while(node != null) {
			node = node.next;
			cont++;
		}
		return cont;
	}
}
