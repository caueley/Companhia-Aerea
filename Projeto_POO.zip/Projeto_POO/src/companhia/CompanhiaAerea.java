package companhia;

import usuario.*;
import estrutura.ListaLigadaPessoa;
import estrutura.ListaLigadaAviao;
import estrutura.ListaLigadaViagens;

import javax.swing.JOptionPane;

import exceptions.NivelDeAcessoException;

public class CompanhiaAerea {
	// ATRIBUTOS
	private String nome;
	private String cnpj;
	private String fundacao;
	private String localizacao;
	private ListaLigadaPessoa clientes;
	private ListaLigadaPessoa funcionarios;
	private ListaLigadaAviao avioes;
	private ListaLigadaViagens viagens;
	
	// M�TODO CONSTRUTOR
	public CompanhiaAerea(String nome, String cnpj, int fundacaoDia, int fundacaoMes, int fundacaoAno, String localizacao) {
		this.nome = nome;
		this.cnpj = cnpj;
		this.fundacao = fundacao;
		this.localizacao = localizacao;
		
		clientes = new ListaLigadaPessoa();
		funcionarios = new ListaLigadaPessoa();
		avioes  = new ListaLigadaAviao();
		viagens = new ListaLigadaViagens();
	}

	// M�TODOS MODIFICADORES
	public String getNome() {
		return nome;
	}
	
	public String getCnpj() {
		return cnpj;
	}

	public Date getFundacao() {
		return fundacao;
	}

	public String getLocalizacao() {
		return localizacao;
	}

	public ListaLigadaPessoa getClientes() {
		return clientes;
	}
	
	public ListaLigadaPessoa getFuncionarios() {
		return funcionarios;
	}
	
	public ListaLigadaAviao getAeronaves() {
		return avioes;
	}
	
	public ListaLigadaViagens getViagens() {
		return viagens;
	}

	// M�TODOS PERSONALIZADOS
	public Pessoa adicionaCliente() throws Exception {
		String nome = JOptionPane.showInputDialog("Digite o nome completo: ");
		int dia = Integer.parseInt(JOptionPane.showInputDialog("Digite o dia do nascimento: "));
		int mes = Integer.parseInt(JOptionPane.showInputDialog("Digite o m�s do nascimento: "));
		int ano = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano nascimento: "));
		Date dataNascimento = new Date(dia, mes, ano);
		String cpf = JOptionPane.showInputDialog("Digite o CPF: ");
		String user = JOptionPane.showInputDialog("Digite o usu�rio para acesso o sistema: ");
		String password = JOptionPane.showInputDialog("Digite a senha para acesso ao sistema: ");

		try {
			Cliente novoCliente = new Cliente(nome, dataNascimento, cpf, user, password);
			clientes.adicionaPessoa(novoCliente);
			return novoCliente;
		} catch(Exception e) {
			throw e;
		}
	}
	
	public void removeCliente(Pessoa pessoa) throws Exception {
		if(pessoa.getNivelDeAcesso() == 1) {	
			try {
				int id = Integer.parseInt(JOptionPane.showInputDialog("Clientes: " + clientes.listarPessoas() + 
						"\nDigite o ID do cliente que deseja remover: "));
				clientes.removePessoa(id);
			} catch(Exception e) {
				throw e;
			}
		} else {
			throw new NivelDeAcessoException();
		}
	}

	public void adicionaFuncionario(Pessoa pessoa) throws Exception {
		if(pessoa.getNivelDeAcesso() == 1) {
			String nome = JOptionPane.showInputDialog("Digite o nome completo do funcion�rio: ");
			int dia = Integer.parseInt(JOptionPane.showInputDialog("Digite o dia do nascimento do funcion�rio: "));
			int mes = Integer.parseInt(JOptionPane.showInputDialog("Digite o m�s do nascimento do funcion�rio: "));
			int ano = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano nascimento do funcion�rio: "));
			Date dataNascimento = new Date(dia, mes, ano);
			String cpf = JOptionPane.showInputDialog("Digite o CPF do funcion�rio: ");
			float salario = Float.parseFloat(JOptionPane.showInputDialog("Digite o sal�rio do funcion�rio: "));
			String user = JOptionPane.showInputDialog("Digite o usu�rio para acesso o sistema do funcion�rio: ");
			String password = JOptionPane.showInputDialog("Digite a senha para acesso ao sistema do funcion�rio: ");
			String cargo = JOptionPane.showInputDialog("Digite o cargo do funcion�rio: ");
			
			try {
				Funcionario novoFuncionario = null;
				if(cargo.equals("Atendente")) {
					novoFuncionario = new Atendente(nome, dataNascimento, cpf, salario, user, password);
				} else {
					if(cargo.equals("Comiss�rio")) {
						novoFuncionario = new Comissario(nome, dataNascimento, cpf, salario, user, password);
					} else {
						if(cargo.equals("Piloto")) {
							novoFuncionario = new Piloto(nome, dataNascimento, cpf, salario, user, password);
						} else {
							throw new Exception("Valor para cargo n�o permitido");
						}
					}
				}
				funcionarios.adicionaPessoa(novoFuncionario);
			} catch(Exception e) {
				throw e;
			}
		} else {
			throw new NivelDeAcessoException();
		}
	}
	
	public void removeFuncionario(Pessoa pessoa) throws Exception {
		if(pessoa.getNivelDeAcesso() == 1) {
			try {
				int id = Integer.parseInt(JOptionPane.showInputDialog("Funcion�rios: \n" + funcionarios.listarPessoas() + 
						"\nDigite o ID do funcion�rio que deseja remover: "));
				funcionarios.removePessoa(id);
			} catch(Exception e) {
				throw e;
			}
		} else {
			throw new NivelDeAcessoException();
		}
	}

	public void adicionaAviao(Pessoa pessoa) throws Exception {
		if(pessoa.getNivelDeAcesso() == 1) {
		} else {
			throw new NivelDeAcessoException();
		}
	}
	
	public void removeAviao(Pessoa pessoa) throws Exception {
		if(pessoa.getNivelDeAcesso() == 1) {
		} else {
			throw new NivelDeAcessoException();
		}
	}

	public void adicionaViagem(Pessoa pessoa) throws Exception {
		if(pessoa.getNivelDeAcesso() == 2) {
		} else {
			throw new NivelDeAcessoException();
		}
	}
	
	public void removeViagem(Pessoa pessoa) throws Exception {
		if(pessoa.getNivelDeAcesso() == 2) {
		} else {
			throw new NivelDeAcessoException();
		}
	}
	
	public String info() {
		return "Nome da Companhia: " + getNome() + "\nCNPJ: " + getCnpj() + 
				"\nFunda��o: " + getFundacao() + "\nLocaliza��o: " + getLocalizacao() + 
				"\nN� de Funcion�rios: " + funcionarios.tamanhoDaLista() + "\nN� de Clientes: " + clientes.tamanhoDaLista();
	}
	
	public Pessoa verificaLogin(String tipo, String usuario, String senha) {
		if(tipo.equals("Cliente")) {
			return clientes.verificaLogin(usuario, senha);
		} else {
			return funcionarios.verificaLogin(usuario, senha);
		}
	}
	
}

