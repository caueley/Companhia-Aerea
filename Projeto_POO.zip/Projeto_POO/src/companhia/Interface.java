package companhia;

import javax.swing.JOptionPane;

import exceptions.NaoCadastradoException;
import exceptions.OpcaoInvalidaException;
import usuario.Pessoa;

public class Interface {
	// ATRIBUTO
	private CompanhiaAerea companhiaAerea;
	private Pessoa sessaoAtual;

	// M�TODO CONSTRUTOR
	public Interface(CompanhiaAerea companhiaAerea) {
		this.companhiaAerea = companhiaAerea;
		this.sessaoAtual = null;
	}

	// M�TODOS MODIFICADORES
	public Pessoa getSessaoAtual() {
		return sessaoAtual;
	}
	public void setSessaoAtual(Pessoa sessaoAtual) {
		this.sessaoAtual = sessaoAtual;
	}
	
	public CompanhiaAerea getCompanhiaAerea() {
		return companhiaAerea;
	}
	
	// M�TODOS PERSONALIZADOS
	public int paginaInicial() throws Exception {
		int opcao;
		opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Seja muito bem-vindo a " + companhiaAerea.getNome() + "!\n\n"
				+ "1. Login\n2. Novo Usu�rio\n3. Informa��es da ABC AirLines\n4. Encerrar Sistema\n\n", companhiaAerea.getNome(), 3));

		if(opcao < 1 || opcao > 4) {
			throw new OpcaoInvalidaException();
		}
		return opcao;
	} 

	public void login() throws Exception {
		int tipoLogin = Integer.parseInt(JOptionPane.showInputDialog(null, "Qual o tipo de acesso que deseja realizar?"
				+ "\n1. Cliente\n2. Funcion�rio\n3. Voltar", "ABC AirLines", 3));

		String usuario = null, senha = null;
		if(tipoLogin == 1 || tipoLogin == 2) {
			usuario = JOptionPane.showInputDialog(null, "Digite o usu�rio:", "ABC AirLines", 3);
			senha = JOptionPane.showInputDialog(null, "Digite a senha:", "ABC AirLines", 3);
		}
		
		switch(tipoLogin) {
			case 1:
				setSessaoAtual(companhiaAerea.verificaLogin("Cliente", usuario, senha));
				if(getSessaoAtual() != null) {
					telaCliente(getSessaoAtual());
					setSessaoAtual(null);
				} else {
					throw new NaoCadastradoException("cliente");
				}
				break;
			case 2:
				setSessaoAtual(companhiaAerea.verificaLogin("Funcion�rio", usuario, senha));
				if(getSessaoAtual() != null) {
					telaFuncionario(getSessaoAtual());
					setSessaoAtual(null);
				} else {
					throw new NaoCadastradoException("funcion�rio(a)");
				}
				break;	
			case 3:
				break;
			default:
				throw new OpcaoInvalidaException();
			}
	}
	
	public void novoUsuario() throws Exception {
		setSessaoAtual(companhiaAerea.adicionaCliente());
		telaCliente(getSessaoAtual());
		setSessaoAtual(null);
	}
	
	private void telaCliente(Pessoa sessaoAtual) {
		JOptionPane.showMessageDialog(null, "Ol�, " + sessaoAtual.getNomeCompleto() + "!");
		setSessaoAtual(null);
	}
	
	private void telaFuncionario(Pessoa sessaoAtual) {
		JOptionPane.showMessageDialog(null, "Ol�, Funcion�rio!");
	}
}
