package companhia;

import usuario.Cliente;
import exceptions.NivelDeAcessoException;
import exceptions.ValorInvalidoException;

public class Aviao {
	// ATRIBUTOS
	private int id;
	private String modelo;
	private Viagem proxViagem;
	private int capacidade;
	private Cliente[] passageiros;
	
	// M�TODO CONSTRUTOR
	public Aviao(String modelo, int capacidade) {
		this.modelo = modelo;
		this.capacidade = capacidade;
		this.id = 0;
		passageiros = new Cliente[capacidade];
	}

	// M�TODOS MODIFICADORES
	public int getId() {
		return id;
	}	
	public void setId(int id) throws Exception {
		if(this.id == 0) {
			this.id = id;
		} else {
			throw new NivelDeAcessoException();
		}
	}
	
	public String getModelo() {
		return modelo;
	}
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public Viagem getProxViagem() {
		return proxViagem;
	}
	public void setProxViagem(Viagem proxViagem) {
		this.proxViagem = proxViagem;
	}

	public int getCapacidade() {
		return capacidade;
	}
	public void setCapacidade(int capacidade) throws Exception {
		if(capacidade > 0) {
			this.capacidade = capacidade;
		} else {
			throw new ValorInvalidoException("capacidade");
		}
	}
	
	public Cliente[] getPassageiros() {
		return passageiros;
	}
	public void setPassageiros(Cliente[] passageiros) {
		this.passageiros = passageiros;
	}
	
	// M�TODOS PERSONALIZADOS
	public String info() {
		return "ID" + getId() + "	Modelo: " + getModelo() + "		Capacidade: " + getCapacidade() 
		+ "		Pr�xima Viagem: " + proxViagem.getDestino();
	}
}
