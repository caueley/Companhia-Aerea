package usuario;

import java.util.Date;

public class Cliente extends Pessoa {
	public Cliente (String nomeCompleto, Date dataDeNascimento, String cpf, String usuario, String senha) {
		super(nomeCompleto, dataDeNascimento, cpf, usuario, senha, 3);
	}
}
