package usuario;

import java.util.Date;

public abstract class Funcionario extends Pessoa {
	// ATRIBUTOS
	private String cargo;
	private float salario;
	
	// M�TODO CONSTRUTOR
	public Funcionario (String nomeCompleto, Date dataDeNascimento, String cpf, String cargo, float salario, String usuario, String senha) {
		super(nomeCompleto, dataDeNascimento, cpf, usuario, senha, 2);
		setCargo(cargo);
		setSalario(salario);
	}

	// M�TODOS MODIFICADORES
	public String getCargo() {
		return cargo;
	}
	
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public float getSalario() {
		return salario;
	}
	
	public void setSalario(float salario) {
		this.salario = salario;
	}
	
	
}
