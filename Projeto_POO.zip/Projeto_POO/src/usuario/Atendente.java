package usuario;

import java.util.Date;

public class Atendente extends Funcionario {
	// M�TODO CONSTRUTOR
	public Atendente(String nomeCompleto, Date dataDeNascimento, String cpf, float salario, String usuario, String senha) {
		super(nomeCompleto, dataDeNascimento, cpf, "Atendente", salario, usuario, senha);
	}
}
