package usuario;

import java.util.Date;

public class Comissario extends Funcionario {
	// M�TODO CONSTRUTOR
	public Comissario(String nomeCompleto, Date dataDeNascimento, String cpf, float salario, String usuario, String senha) {
		super(nomeCompleto, dataDeNascimento, cpf, "Comiss�rio", salario, usuario, senha);
	}
}
