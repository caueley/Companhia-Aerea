package usuario;

public class Administrador {
}
