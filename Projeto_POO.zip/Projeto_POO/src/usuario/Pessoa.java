package usuario;

import java.util.Date;
import exceptions.NivelDeAcessoException;

public abstract class Pessoa {
	// ATRIBUTOS
	private int id;
	private int nivelDeAcesso;
	private String nomeCompleto;
	private Date dataDeNascimento;
	private String cpf;
	private int milhas;
	private String usuario;
	private String senha;
	
	// M�TODO CONSTRUTOR
	public Pessoa(String nomeCompleto, Date dataDeNascimento, String cpf, String usuario, String senha, int nivelDeAcesso) {
		this.nomeCompleto = nomeCompleto;
		this.dataDeNascimento = dataDeNascimento;
		this.cpf = cpf;
		this.usuario = usuario;
		this.senha = senha;
		this.id = 0;
		this.milhas = 0;
	}

	// M�TODOS MODIFICADORES
	public int getId() {
		return id;
	}
	public void setId(int id) throws Exception {
		if(this.id == 0) {
			this.id = id;
		} else {
			throw new NivelDeAcessoException();
		}
	}
	
	public int getNivelDeAcesso() {
		return nivelDeAcesso;
	}

	public String getNomeCompleto() {
		return nomeCompleto;
	}
	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public Date getDataDeNascimento() {
		return dataDeNascimento;
	}
	public void setDataDeNascimento(Date dataDeNascimento) {
		this.dataDeNascimento = dataDeNascimento;
	}

	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}

	public int getMilhas() {
		return milhas;
	}
	public void setMilhas(int milhas) {
		this.milhas = milhas;
	}
	
}
