package usuario;

import java.util.Date;

public class Piloto extends Funcionario {
	// M�TODO CONSTRUTOR
	public Piloto(String nomeCompleto, Date dataDeNascimento, String cpf, float salario, String usuario, String senha) {
		super(nomeCompleto, dataDeNascimento, cpf, "Piloto", salario, usuario, senha);
	}
}
