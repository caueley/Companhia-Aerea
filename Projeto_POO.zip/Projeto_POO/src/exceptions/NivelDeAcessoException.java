package exceptions;

public class NivelDeAcessoException extends Exception {
	public NivelDeAcessoException() {
		super("Voc� n�o possui permiss�o para realizar esta opera��o.");
	}
}
