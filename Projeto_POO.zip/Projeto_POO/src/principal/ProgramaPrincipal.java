package principal;

import companhia.CompanhiaAerea;
import companhia.Interface;
import java.util.Date;
import exceptions.OpcaoInvalidaException;

import javax.swing.JOptionPane;

public class ProgramaPrincipal {
	public static void main(String[] args) {
		CompanhiaAerea abcAirLines = new CompanhiaAerea("ABC AirLines", "12.345.678/0001-90", new Date(3, 6, 2019), "Santo Andr�");
		Interface sistemaAbcAirLines = new Interface(abcAirLines);

		int opcao = 0;
		do {
			try {
				opcao = sistemaAbcAirLines.paginaInicial();
				switch(opcao) {
					case 1:
						sistemaAbcAirLines.login();
						break;
					case 2:
						sistemaAbcAirLines.novoUsuario();
						break;
					case 3:
						JOptionPane.showMessageDialog(null, abcAirLines.info());
						break;
					case 4:
						break;
					default:
						throw new OpcaoInvalidaException();
				}
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), abcAirLines.getNome(), 2);
			} 
		} while(opcao != 4);
		
		
	}
}
