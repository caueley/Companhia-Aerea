package estrutura;

import exceptions.RepetidoException;
import exceptions.NaoCadastradoException;
import exceptions.ValorInvalidoException;
import exceptions.NadaCadastradoException;

import participantes.Pessoa;

public class ListaLigadaPessoa {
	private class LinkedNode {
		private Pessoa data;
		private LinkedNode next;
	}

	private LinkedNode first;

	public void adicionaPessoa(Pessoa pessoa) throws Exception {
		LinkedNode novaPessoa = new LinkedNode();
		novaPessoa.data = pessoa;
		novaPessoa.next = null;

		if(first == null) {
			if(novaPessoa.data.getId() != -1) novaPessoa.data.setId(1);
			this.first = novaPessoa;
		} else {
			LinkedNode anterior = null;
			LinkedNode atual = first;
			int id = 0;

			while(atual != null) {
				if(novaPessoa.data.getCpf().equals(atual.data.getCpf())) {
					throw new RepetidoException("CPF");
				} else if(novaPessoa.data.getUsuario().equals(atual.data.getUsuario())) {
					throw new RepetidoException("usu�rio");
				}

				if(atual != null) id = atual.data.getId();

				anterior = atual;
				atual = atual.next;
			}

			if(novaPessoa.data.getId() != -1) {
				novaPessoa.data.setId(id+1);
			}
			anterior.next = novaPessoa;
		}
	}

	public void removePessoa(int id) throws Exception {
		if(id > 0) {
			LinkedNode anterior = null;
			LinkedNode atual = first;

			while(atual != null && atual.data.getId() != id) {
				anterior = atual;
				atual = atual.next;
			}

			if(atual != null) {
				if(anterior == null) {
					first = atual.next;
				} else {
					anterior.next = atual.next;
				}
			} else {
				throw new NaoCadastradoException("pessoa");
			}
		} else {
			throw new ValorInvalidoException("id");
		}
	}

	public String listarPessoas() throws Exception {
		LinkedNode node = first;
		String lista = "";
		while(node != null) {
			lista += node.data.info();
			node = node.next;
		}
		if(!lista.isEmpty()) {
			return lista;
		} else {
			throw new NadaCadastradoException("pessoa");
		}
	}

	public int tamanhoDaLista() {
		LinkedNode node = first;
		int cont = 0;
		while(node != null) {
			node = node.next;
			cont++;
		}
		return cont;
	}

	public Pessoa verificaLogin(String usuario, String senha) {
		LinkedNode node = first;
		while(node != null && !node.data.getUsuario().equals(usuario)) {
			node = node.next;
		}

		if(node == null) {
			return null;
		} else {
			if(node.data.getSenha().equals(senha)) {
				return node.data;
			}
			else {
				return null;
			}
		}
	}

}
