package estrutura;

public interface Informacoes {
	public String info();
}
