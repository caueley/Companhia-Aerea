package estrutura;

import exceptions.RepetidoException;
import exceptions.NaoCadastradoException;
import exceptions.ValorInvalidoException;
import exceptions.NadaCadastradoException;

import participantes.Cliente;

public class ListaLigadaCliente {
	private class LinkedNode {
		private Cliente data;
		private LinkedNode next;
	}

	private LinkedNode first;

	public void adicionaCliente(Cliente cliente) throws Exception {
		LinkedNode novoCliente = new LinkedNode();
		novoCliente.data = cliente;
		novoCliente.next = null;

		if(first == null) {
			if(novoCliente.data.getId() != -1) novoCliente.data.setId(1);
			this.first = novoCliente;
		} else {
			LinkedNode anterior = null;
			LinkedNode atual = first;
			int id = 0;

			while(atual != null) {
				if(novoCliente.data.getCpf().equals(atual.data.getCpf())) {
					throw new RepetidoException("CPF");
				} else if(novoCliente.data.getUsuario().equals(atual.data.getUsuario())) {
					throw new RepetidoException("cliente");
				}

				if(atual != null) id = atual.data.getId();

				anterior = atual;
				atual = atual.next;
			}

			if(novoCliente.data.getId() != -1) {
				novoCliente.data.setId(id+1);
			}
			anterior.next = novoCliente;
		}
	}

	public void removeCliente(int id) throws Exception {
		if(id > 0) {
			LinkedNode anterior = null;
			LinkedNode atual = first;

			while(atual != null && atual.data.getId() != id) {
				anterior = atual;
				atual = atual.next;
			}

			if(atual != null) {
				if(anterior == null) {
					first = atual.next;
				} else {
					anterior.next = atual.next;
				}
			} else {
				throw new NaoCadastradoException("cliente");
			}
		} else {
			throw new ValorInvalidoException("ID");
		}
	}

	public String listarClientes() throws Exception {
		LinkedNode node = first;
		String lista = "";
		while(node != null) {
			lista += node.data.info();
			node = node.next;
		}
		if(!lista.isEmpty()) {
			return lista;
		} else {
			throw new NadaCadastradoException("cliente");
		}
	}

	public int tamanhoDaLista() {
		LinkedNode node = first;
		int cont = 0;
		while(node != null) {
			node = node.next;
			cont++;
		}
		return cont;
	}

	public Cliente verificaLogin(String usuario, String senha) {
		LinkedNode node = first;
		while(node != null && !node.data.getUsuario().equals(usuario)) {
			node = node.next;
		}

		if(node == null) {
			return null;
		} else {
			if(node.data.getSenha().equals(senha)) {
				return node.data;
			}
			else {
				return null;
			}
		}
	}
	
}
