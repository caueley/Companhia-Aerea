package estrutura;

import exceptions.NaoCadastradoException;
import exceptions.NadaCadastradoException;

import participantes.Aviao;

public class ListaLigadaAviao {
	private class LinkedNode {
		private Aviao data;
		private LinkedNode next;
	}

	private LinkedNode first;

	public void adicionaAviao(Aviao aviao) throws Exception {
		LinkedNode novoAviao = new LinkedNode();
		novoAviao.data = aviao;
		novoAviao.next = null;

		if(first == null) {
			novoAviao.data.setId(1);
			this.first = novoAviao;
		} else {
			LinkedNode anterior = null;
			LinkedNode atual = first;
			int id = 0;
			
			while(atual != null) {
				if(atual != null) id = atual.data.getId();
				
				anterior = atual;
				atual = atual.next;
			}
			novoAviao.data.setId(id+1);
			anterior.next = novoAviao;
		}
	}

	public void removeAviao(int id) throws Exception {
		LinkedNode anterior = null;
		LinkedNode atual = first;

		while(atual != null && atual.data.getId() != id) {
			anterior = atual;
			atual = atual.next;
		}

		if(atual != null) {
			if(anterior == null) {
				first = atual.next;
			} else {
				anterior.next = atual.next;
			}
		} else {
			throw new NaoCadastradoException("avi�o");
		}
	}

	public String listarAvioes() throws Exception {
		LinkedNode node = first;
		String lista = "";
		while(node != null) {
			lista += node.data.info();
			node = node.next;
		}
		if(!lista.isEmpty()) {
			return lista;
		} else {
			throw new NadaCadastradoException("avi�o");
		}
	}

	public int tamanhoDaLista() {
		LinkedNode node = first;
		int cont = 0;
		while(node != null) {
			node = node.next;
			cont++;
		}
		return cont;
	}
}
