package estrutura;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JOptionPane;

import participantes.Pessoa;
import participantes.Aviao;
import participantes.Cliente;
import participantes.Funcionario;

public class CiaAerea implements Informacoes {

	// ATRIBUTOS
	private static CiaAerea objetoUnico;

	private String nome;
	private String cnpj;
	private String fundacao;
	private String localizacao;
	private ListaLigadaAviao avioes;
	private ListaLigadaViagens viagens;
	private ListaLigadaCliente clientes;
	private ListaLigadaFuncionario funcionarios;

	// M�TODO CONSTRUTOR
	private CiaAerea() {	
		clientes = new ListaLigadaCliente();
		funcionarios = new ListaLigadaFuncionario();
		avioes  = new ListaLigadaAviao();
		viagens = new ListaLigadaViagens();
		
		try {
			// Cadastrando os usu�rios quando o sistema � executado
			Pessoa [] usuariosIniciais = Pessoa.criarUsuariosIniciais();
			for(Pessoa v: usuariosIniciais) {
				if(v instanceof Cliente) {
					clientes.adicionaCliente((Cliente) v);
				} else {
					funcionarios.adicionaFuncionario((Funcionario) v);
				}
			}
			
			// Cadastrando os avi�es quando o sistema � executado
			Aviao[] avioesIniciais = Aviao.criarAvioesIniciais();
			for(Aviao v: avioesIniciais) {
				avioes.adicionaAviao(v);
			}
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, "Problema para criarcadastrar usu�rios iniciais");
		}
	}

	public static CiaAerea getInstance() {
		if(objetoUnico == null) {
			objetoUnico = new CiaAerea();
		}
		return objetoUnico;
	}

	// M�TODOS MODIFICADORES
	public void setNome(String nome) {
		if(this.nome == null) {
			this.nome = nome;
		}
	}

	public String getNome() {
		return nome;
	}

	public void setCnpj(String cnpj) {
		if(this.cnpj == null) {
			this.cnpj = cnpj;
		}
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setFundacao(int dia, int mes, int ano) {
		if(this.fundacao == null) {
			this.fundacao = formatarData(dia, mes, ano);
		}
	}

	public String getFundacao() {
		return fundacao;
	}

	public void setLocalizacao(String localizacao) {
		if(this.localizacao == null) {
			this.localizacao = localizacao;
		}
	}

	public String getLocalizacao() {
		return localizacao;
	}

	public ListaLigadaAviao getAvioes() {
		return avioes;
	}

	public ListaLigadaViagens getViagens() {
		return viagens;
	}

	public ListaLigadaCliente getClientes() {
		return clientes;
	}

	public ListaLigadaFuncionario getFuncionarios() {
		return funcionarios;
	}

	// M�TODOS PERSONALIZADOS

	// Verifica se a pessoa que esta tentando acessar o sistema utilizou um usuario e senha que estejam cadastrados
	public Pessoa verificaLogin(String tipo, String usuario, String senha) {
		if(tipo.equals("Cliente")) {
			return clientes.verificaLogin(usuario, senha);
		} else {
			return funcionarios.verificaLogin(usuario, senha);
		}
	}

	// Retorna data padronizada
	public static String formatarData(int dia, int mes, int ano) {
		GregorianCalendar data = new GregorianCalendar(ano, mes, dia);
		SimpleDateFormat dataFormatada = new SimpleDateFormat("dd/MM/yyyy");
		return dataFormatada.format(data.getTime());
	}

	// Retorna hor�rio padronizado
	public static String formatarHorario(int dia, int mes, int ano, int hora, int minuto) {
		GregorianCalendar dataEHorario = new GregorianCalendar(ano, mes, dia, hora, minuto);
		SimpleDateFormat horarioFormatado = new SimpleDateFormat("HH:mm");
		return horarioFormatado.format(dataEHorario.getTime());
	}

	// Retorna o ano atual
	public static int anoAtual() {
		Calendar hoje = Calendar.getInstance();
		return hoje.get(Calendar.YEAR);
	}
	
	// Retorna as informa��es da companhia a�rea
	@Override
	public String info() {
		return "Nome da Companhia: " + getNome() + "\nCNPJ: " + getCnpj() + 
				"\nFunda��o: " + getFundacao() + "\nLocaliza��o: " + getLocalizacao() + 
				"\nN� de Funcion�rios: " + (funcionarios.tamanhoDaLista()-1) + "\nN� de Avi�es: " + avioes.tamanhoDaLista() 
				+ "\nN� de Clientes: " + clientes.tamanhoDaLista();
	}

}
