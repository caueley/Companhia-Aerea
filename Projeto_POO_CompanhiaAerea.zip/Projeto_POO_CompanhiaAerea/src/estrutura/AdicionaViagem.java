package estrutura;

import participantes.Viagem;

public interface AdicionaViagem {
	public void adicionarViagem(Viagem v) throws Exception;
}
