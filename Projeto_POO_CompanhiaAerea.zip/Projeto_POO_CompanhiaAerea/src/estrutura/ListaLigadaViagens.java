package estrutura;

import exceptions.NaoCadastradoException;
import exceptions.NadaCadastradoException;

import participantes.Viagem;
import sistema.InterfaceDoSistema;

public class ListaLigadaViagens {
	private class LinkedNode {
		private Viagem data;
		private LinkedNode next;
	}

	private LinkedNode first;

	public void adicionaViagem(Viagem viagem) throws Exception {
		LinkedNode novaViagem = new LinkedNode();
		novaViagem.data = viagem;
		novaViagem.next = null;

		if(first == null) {
			novaViagem.data.setId(1);
			this.first = novaViagem;
		} else {
			LinkedNode anterior = null;
			LinkedNode atual = first;
			int id = 0;

			while(atual != null) {
				if(atual != null) id = atual.data.getId();

				anterior = atual;
				atual = atual.next;
			}
			novaViagem.data.setId(id+1);
			anterior.next = novaViagem;
		}
	}

	public void removeViagem(int id) throws Exception {
		LinkedNode anterior = null;
		LinkedNode atual = first;

		while(atual != null && atual.data.getId() != id) {
			anterior = atual;
			atual = atual.next;
		}

		if(atual != null) {
			if(anterior == null) {
				first = atual.next;
			} else {
				anterior.next = atual.next;
			}
		} else {
			throw new NaoCadastradoException("viagem");
		}
	}

	public String listarViagens() throws Exception {
		LinkedNode node = first;
		String lista = "";
		while(node != null) {
			lista += node.data.info();
			node = node.next;
		}
		if(!lista.isEmpty()) {
			return lista;
		} else {
			throw new NadaCadastradoException("viagem");
		}
	}

	public String listarViagensAvancado(String origem, String destino) throws Exception {
		LinkedNode node = first;
		String lista = "";
		while(node != null) {
			if(node.data.getOrigem().equals(origem) && node.data.getDestino().equals(destino)) {
				lista += node.data.info();
			}
			node = node.next;
		}
		if(!lista.isEmpty()) {
			return lista;
		} else {
			throw new NadaCadastradoException("viagem");
		}
	}
	
	public String listarViagensAvancado(int dia, int mes, int ano) throws Exception {
		LinkedNode node = first;
		String lista = "";
		while(node != null) {
			if(node.data.getHorario().equals(InterfaceDoSistema.formatarData(dia, mes, ano))) {
				lista += node.data.info();
			}
			node = node.next;
		}
		if(!lista.isEmpty()) {
			return lista;
		} else {
			throw new NadaCadastradoException("viagem");
		}
	}

	public String listarViagensAvancado(int hora, int minuto) throws Exception {
		LinkedNode node = first;
		String lista = "";
		while(node != null) {
			if(node.data.getHorario().equals(InterfaceDoSistema.formatarHorario(0, 0, 0, hora, minuto))) // Como quero saber s� o horario, pouco importa o que � passado na data.
			lista += node.data.info();
			node = node.next;
		}
		if(!lista.isEmpty()) {
			return lista;
		} else {
			throw new NadaCadastradoException("passagem");
		}
	}

	public Viagem buscarViagem(int id) throws Exception {
		LinkedNode node = first;
		
		while(node != null && node.data.getId() != id) {
			node = node.next;
		}
		
		if(node != null) {
			return node.data;
		} else {
			throw new NaoCadastradoException("viagem");
		}
	}
	
	public int tamanhoDaLista() {
		LinkedNode node = first;
		int cont = 0;
		while(node != null) {
			node = node.next;
			cont++;
		}
		return cont;
	}
	
}
