package estrutura;

import exceptions.RepetidoException;
import exceptions.OpcaoInvalidaException;
import exceptions.NaoCadastradoException;
import exceptions.ValorInvalidoException;
import exceptions.NadaCadastradoException;

import participantes.Funcionario;

public class ListaLigadaFuncionario {
	private class LinkedNode {
		private Funcionario data;
		private LinkedNode next;
	}

	private LinkedNode first;

	// Cadastra um novo funcion�rio no sistema
	public void adicionaFuncionario(Funcionario funcionario) throws Exception {
		LinkedNode novoFuncionario = new LinkedNode();
		novoFuncionario.data = funcionario;
		novoFuncionario.next = null;

		if(first == null) {
			if(novoFuncionario.data.getId() != -1) novoFuncionario.data.setId(1);
			this.first = novoFuncionario;
		} else {
			LinkedNode anterior = null;
			LinkedNode atual = first;
			int id = 0;

			while(atual != null) {
				if(novoFuncionario.data.getCpf().equals(atual.data.getCpf())) {
					throw new RepetidoException("CPF");
				} else if(novoFuncionario.data.getUsuario().equals(atual.data.getUsuario())) {
					throw new RepetidoException("usu�rio");
				}

				if(atual != null) id = atual.data.getId();

				anterior = atual;
				atual = atual.next;
			}

			if(novoFuncionario.data.getId() != -1) {
				novoFuncionario.data.setId(id+1);
			}
			anterior.next = novoFuncionario;
		}
	}

	// Remove um funcion�rio cadastrado do sistema
	public void removeFuncionario(int id) throws Exception {
		if(id > 0) {
			LinkedNode anterior = null;
			LinkedNode atual = first;

			while(atual != null && atual.data.getId() != id) {
				anterior = atual;
				atual = atual.next;
			}

			if(atual != null) {
				if(anterior == null) {
					first = atual.next;
				} else {
					anterior.next = atual.next;
				}
			} else {
				throw new NaoCadastradoException("pessoa");
			}
		} else {
			throw new ValorInvalidoException("ID");
		}
	}

	// Lista todos os funcion�rios cadastrados no sistema
	public String listarFuncionarios() throws Exception {
		LinkedNode node = first;
		String listaFuncionarios = "";
		while(node != null) {
			listaFuncionarios += node.data.info();
			node = node.next;
		}
		if(!listaFuncionarios.isEmpty()) {
			return listaFuncionarios;
		} else {
			throw new NadaCadastradoException("pessoa");
		}
	}

	// Lista todos os pilotos cadastrados no sistema
	public String listarPilotos(int id) throws Exception {
		LinkedNode node = first;
		String listaPilotos = "";
		while(node != null) {
			if(node.data.getCargo().equals("Piloto") && node.data.getId() != id) {
				listaPilotos += node.data.info();
			}
			node = node.next;
		}

		if(!listaPilotos.isEmpty()) {
			return listaPilotos;
		} else {
			throw new NadaCadastradoException("piloto");
		}
	}

	// Lista todos os comiss�rios cadastrados no sistema
	public String listarComissarios(int id) throws Exception {
		LinkedNode node = first;
		String listaComissarios = "";
		while(node != null) {
			if(node.data.getCargo().equals("Comiss�rio") && node.data.getId() != id) {
				listaComissarios += node.data.info();
			}
			node = node.next;
		}

		if(!listaComissarios.isEmpty()) {
			return listaComissarios;
		} else {
			throw new NadaCadastradoException("comiss�rio");
		}
	}

	// Retorna o n�mero de funcion�rios cadastrados no sistema
	public int tamanhoDaLista() {
		LinkedNode node = first;
		int cont = 0;
		while(node != null) {
			node = node.next;
			cont++;
		}
		return cont;
	}

	/* Retorna o objeto funcion�rio procurado para o ponto em que a fun��o � chamada, por�m, esse funcion�rio n�o pode possuir o ID 1 passado como par�metro
	 * e deve ter o mesmo cargo ao igual passado como par�metro do m�todo */
	public Funcionario buscarFuncionario(int id1, int id2, String cargo) throws Exception {
		LinkedNode node = first;

		while(node != null && node.data.getId() != id2) {
			node = node.next;
		}

		if(node != null) {
			if(node.data.getCargo().equals(cargo) && node.data.getId() != id1) {
				return node.data;
			} else {
				throw new OpcaoInvalidaException();
			}
		} else {
			throw new NaoCadastradoException(cargo.toLowerCase());
		}
	}

	// Verifica se aquele usu�rio e senha est�o cadastrados no sistema
	public Funcionario verificaLogin(String usuario, String senha) {
		LinkedNode node = first;
		while(node != null && !node.data.getUsuario().equals(usuario)) {
			node = node.next;
		}

		if(node == null) {
			return null;
		} else {
			if(node.data.getSenha().equals(senha)) {
				return node.data;
			}
			else {
				return null;
			}
		}
	}

}
