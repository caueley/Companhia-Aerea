package telas;

import javax.swing.JOptionPane;

import exceptions.OpcaoInvalidaException;

import estrutura.CiaAerea;

import participantes.Aviao;
import participantes.Viagem;
import participantes.Piloto;
import participantes.Atendente;
import participantes.Comissario;
import participantes.Funcionario;
import participantes.Administrador;

public class TelaFuncionario {
	// ATRIBUTO
	private Funcionario sessaoAtual;

	// M�TODO CONSTRUTOR
	public TelaFuncionario(Funcionario sessaoAtual) {
		this.sessaoAtual = sessaoAtual;
	}

	// M�TODO MODIFICADOR
	private Funcionario getSessaoAtual() {
		return sessaoAtual;
	}

	// M�TODOS PERSONALIZADOS

	// Tela inicial da conta do tipo funcion�rio (varia de acordo com o cargo)
	public void telaFuncionario() {
		// Tela do funcion�rio do tipo Administrador
		if(getSessaoAtual() instanceof Administrador) {
			int opcao = 0;
			do {
				try {
					opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Ol�, " + getSessaoAtual().getNome() +
							"!\n\n[1] Remover Cliente\n[2] Adicionar Funcion�rio\n[3] Remover Funcion�rio\n[4] Adicionar Avi�o\n[5] Remover Avi�o"
							+ "\n[6] Logout\n\n", "Administrador - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
					switch(opcao) {
					case 1:
						removeCliente();
						break;
					case 2:
						adicionaFuncionario();
						break;
					case 3:
						removeFuncionario();
						break;
					case 4:
						adicionaAviao();
						break;
					case 5:
						removeAviao();
						break;
					case 6:
						int sair = JOptionPane.showConfirmDialog(null, "Deseja mesmo sair da sua conta?", "Logout - " + 
								CiaAerea.getInstance().getNome(), JOptionPane.YES_NO_OPTION);
						if(sair == JOptionPane.NO_OPTION) opcao = 0;
						break;
					default:
						throw new OpcaoInvalidaException();
					}
				} catch(NumberFormatException e) {
					JOptionPane.showMessageDialog(null, "Op��o Inv�lida", "Administrador - " + CiaAerea.getInstance().getNome(), JOptionPane.ERROR_MESSAGE);
				} catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Administrador - " + CiaAerea.getInstance().getNome() , JOptionPane.ERROR_MESSAGE);
				}
			} while(opcao != 6);

		// Tela do funcion�rio do tipo Atendente
		} else if(getSessaoAtual() instanceof Atendente) {
			int opcao = 0;
			do {
				try {
					opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Ol�, " + getSessaoAtual().getNome() +
							"!\n\n[1] Adicionar Viagem\n[2] Remover Viagem\n[3] Relat�rio de Viagem" + "\n[4] Logout\n\n", 
							"Atendente - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
					switch(opcao) {
					case 1:
						adicionaViagem();
						break;
					case 2:
						removeViagem();
						break;
					case 3:
						relatorioDeVoo();
						break;
					case 4:
						int sair = JOptionPane.showConfirmDialog(null, "Deseja mesmo sair da sua conta?", "Logout - " + 
								CiaAerea.getInstance().getNome(), JOptionPane.YES_NO_OPTION);
						if(sair == JOptionPane.NO_OPTION) opcao = 0;
						break;
					default:
						throw new OpcaoInvalidaException();
					}
				} catch(NumberFormatException e) {
					JOptionPane.showMessageDialog(null, "Op��o Inv�lida", "Atendente - " + CiaAerea.getInstance().getNome(), JOptionPane.ERROR_MESSAGE);
				} catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Atendente - " + CiaAerea.getInstance().getNome(), JOptionPane.ERROR_MESSAGE);
				}
			} while(opcao != 4);

		// Tela do funcion�rio do tipo Piloto	
		} else if(getSessaoAtual() instanceof Piloto) {
			try {
				JOptionPane.showMessageDialog(null, "Ol�, " + getSessaoAtual().getNome() + "!\n\n Pr�ximas viagens:\n\n"
						+ ((Piloto) getSessaoAtual()).listaViagens(), "Piloto - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Piloto - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
			}

		// Tela do funcion�rio do tipo Comiss�rio
		} else if(getSessaoAtual() instanceof Comissario) {
			try {
				JOptionPane.showMessageDialog(null, "Ol�, " + getSessaoAtual().getNome() + "!\n\n Pr�ximas viagens:\n\n"
						+ ((Comissario) getSessaoAtual()).listaViagens(), "Comiss�rio - "+ CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Comiss�rio - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}

	// Remove conta do tipo cliente do sistema
	public void removeCliente() throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Clientes:\n" + CiaAerea.getInstance().getClientes().listarClientes() + 
				"\n\nDigite o ID do cliente que deseja remover:\n\n", 
				"Remo��o de Cliente - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

		int opcao = JOptionPane.showConfirmDialog(null, "Deseja mesmo remover esse cliente?", "Remo��o de Cliente", JOptionPane.YES_NO_OPTION);

		if(opcao == JOptionPane.YES_OPTION) {
			CiaAerea.getInstance().getClientes().removeCliente(id);
			JOptionPane.showMessageDialog(null, "Cliente removido com sucesso!", 
					"Remo��o de Cliente - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
		}
	}

	// Adiciona conta do tipo funcion�rio do sistema
	public void adicionaFuncionario() throws Exception {
		Funcionario novoFuncionario;
		int cargo = 0;

		do {
			cargo = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o cargo do funcion�rio: "
					+ "\n\n1. Atendente\n2. Comiss�rio\n3. Piloto\n\n", 
					"Cadastro de Funcion�rio - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

			switch(cargo) {
			case 1:
				novoFuncionario = new Atendente();
				break;
			case 2:
				novoFuncionario = new Comissario();
				break;
			case 3:
				novoFuncionario = new Piloto();
				break;
			default:
				throw new OpcaoInvalidaException();
			}

		} while(cargo < 1 && cargo > 3);

		novoFuncionario.setNome();
		novoFuncionario.setDataDeNascimento();
		novoFuncionario.setCpf();
		novoFuncionario.setUsuario();
		novoFuncionario.setSenha();

		CiaAerea.getInstance().getFuncionarios().adicionaFuncionario(novoFuncionario);

		JOptionPane.showMessageDialog(null, "Funcion�rio cadastrado com sucesso!", 
				"Cadastro de Funcion�rio - " + CiaAerea.getInstance().getNome(  ), JOptionPane.INFORMATION_MESSAGE);
	}

	// Remove conta do tipo funcion�rio cadastrada no sistema
	public void removeFuncionario() throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Funcion�rios: \n" + CiaAerea.getInstance().getFuncionarios().listarFuncionarios() + 
				"\n\nDigite o ID do funcion�rio que deseja remover: ", "Remo��o de Funcion�rio", 3));

		int opcao = JOptionPane.showConfirmDialog(null, "Deseja mesmo remover esse avi�o?", 
				"Remo��o de Funcion�rio - " + CiaAerea.getInstance().getNome(), JOptionPane.YES_NO_OPTION);

		if(opcao == JOptionPane.YES_OPTION) {
			CiaAerea.getInstance().getFuncionarios().removeFuncionario(id);
			JOptionPane.showMessageDialog(null, "Funcion�rio removido com sucesso!", 
					"Remo��o de Funcion�rio - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
		}
	}

	// Adiciona avi�o no sistema
	public void adicionaAviao() throws Exception {
		Aviao novoAviao = new Aviao();
		novoAviao.setModelo();
		novoAviao.setCapacidade();

		CiaAerea.getInstance().getAvioes().adicionaAviao(novoAviao);

		JOptionPane.showMessageDialog(null, "Avi�o cadastrado com sucesso!", 
				"Cadastro de Avi�o - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
	}

	// Remove avi�o cadastrado no sistema
	public void removeAviao() throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Avi�es: \n" + CiaAerea.getInstance().getAvioes().listarAvioes() + 
				"\n\nDigite o ID do avi�o que deseja remover: ", "Remo��o de Avi�o - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

		int opcao = JOptionPane.showConfirmDialog(null, "Deseja mesmo remover esse avi�o?", 
				"Remo��o de Avi�o - " + CiaAerea.getInstance().getNome(), JOptionPane.YES_NO_OPTION);

		if(opcao == JOptionPane.YES_OPTION) {
			CiaAerea.getInstance().getAvioes().removeAviao(id);
			JOptionPane.showMessageDialog(null, "Avi�o removido com sucesso!", 
					"Remo��o de Avi�o - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
		}
	}

	// Adiciona viagem no sistema
	public void adicionaViagem() throws Exception {
		String origem = JOptionPane.showInputDialog(null, "Origem: ", 
				"Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE);
		String destino = JOptionPane.showInputDialog(null, "Destino: ", 
				"Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE);
		int dia = Integer.parseInt(JOptionPane.showInputDialog(null, "Dia: ", 
				"Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		int mes = Integer.parseInt(JOptionPane.showInputDialog(null, "M�s: ", 
				"Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		int ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Ano: ", 
				"Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		int hora = Integer.parseInt(JOptionPane.showInputDialog(null, "Hora: ", 
				"Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		int minuto = Integer.parseInt(JOptionPane.showInputDialog(null, "Minuto: ", 
				"Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		int preco = Integer.parseInt(JOptionPane.showInputDialog(null, "Pre�o (em reais): ", 
				"Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

		int idAviao = Integer.parseInt(JOptionPane.showInputDialog(null, "Avi�es Cadastrados:\n\n"
				+ CiaAerea.getInstance().getAvioes().listarAvioes() + "\n\nInsira o ID do avi�o que deseja selecionar para essa viagem:"
				, "Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		Aviao aviao = CiaAerea.getInstance().getAvioes().buscarAviao(idAviao);

		int idPiloto = Integer.parseInt(JOptionPane.showInputDialog(null, "Pilotos Cadastrados:\n\n"
				+ CiaAerea.getInstance().getFuncionarios().listarPilotos(0) + "\n\nInsira o ID do Piloto que deseja selecionar para essa viagem:"
				, "Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		Piloto piloto = (Piloto) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(0, idPiloto, "Piloto");

		int idCopiloto = Integer.parseInt(JOptionPane.showInputDialog(null, "Copilotos Cadastrados:\n\n"
				+ CiaAerea.getInstance().getFuncionarios().listarPilotos(idPiloto) + "\n\nInsira o ID do Copiloto que deseja selecionar para essa viagem:"
				, "Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		Piloto copiloto = (Piloto) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(idPiloto, idCopiloto, "Piloto");

		int idComissario1 = Integer.parseInt(JOptionPane.showInputDialog(null, "Comiss�rios Cadastrados:\n\n"
				+ CiaAerea.getInstance().getFuncionarios().listarComissarios(0) + "\n\nInsira o ID do Comiss�rio que deseja selecionar para essa viagem:"
				, "Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		Comissario comissario1 = (Comissario) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(0, idComissario1, "Comiss�rio");

		int idComissario2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Comiss�rios Cadastrados:\n\n"
				+ CiaAerea.getInstance().getFuncionarios().listarComissarios(idComissario1) + 
				"\n\nInsira o ID do Comiss�rio que deseja selecionar para essa viagem:", 
				"Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		Comissario comissario2 = (Comissario) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(idComissario1, idComissario2, "Comiss�rio");

		Viagem novaViagem = new Viagem(origem, destino, dia, mes, ano, hora, minuto, preco, aviao, piloto, copiloto, comissario1, comissario2);
		CiaAerea.getInstance().getViagens().adicionaViagem(novaViagem);

		((Piloto) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(-1, idPiloto, "Piloto")).getProxViagens().add(novaViagem);
		((Piloto) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(-1, idCopiloto, "Piloto")).getProxViagens().add(novaViagem);
		((Comissario) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(-1, idComissario1, "Comiss�rio")).getProxViagens().add(novaViagem);
		((Comissario) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(-1, idComissario2, "Comiss�rio")).getProxViagens().add(novaViagem);

		JOptionPane.showMessageDialog(null, "Viagem cadastrada com sucesso!", 
				"Cadastro de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
	}

	// Remove viagem cadastrada no sistema
	public void removeViagem() throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Viagens:\n" + CiaAerea.getInstance().getViagens().listarViagens() + 
				"\n\nDigite o ID da viagem que deseja remover:\n\n", "Remo��o de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

		if(CiaAerea.getInstance().getViagens().buscarViagem(id).getPassagensCompradas() < 
				CiaAerea.getInstance().getAvioes().buscarAviao(CiaAerea.getInstance().getViagens().buscarViagem(id).getAviao().getId()).getCapacidade()/2) {

			int opcao = JOptionPane.showConfirmDialog(null, "Deseja mesmo remover essa viagem?", 
					"Remo��o de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.YES_NO_OPTION);

			if(opcao == JOptionPane.YES_OPTION) {
				// Removendo da lista do piloto
				((Piloto) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(-1, CiaAerea.getInstance().getViagens().buscarViagem(id).getPiloto().getId(), 
						"Piloto")).getProxViagens().remove(CiaAerea.getInstance().getViagens().buscarViagem(id));
				// Removendo da lista do piloto
				((Piloto) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(-1, CiaAerea.getInstance().getViagens().buscarViagem(id).getCopiloto().getId(), 
						"Piloto")).getProxViagens().remove(CiaAerea.getInstance().getViagens().buscarViagem(id));
				// Removendo da lista do comiss�rio 1
				((Comissario) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(-1, CiaAerea.getInstance().getViagens().buscarViagem(id).
						getComissario1().getId(), "Comiss�rio")).getProxViagens().remove(CiaAerea.getInstance().getViagens().buscarViagem(id));
				// Removendo da lista do comiss�rio 2
				((Comissario) CiaAerea.getInstance().getFuncionarios().buscarFuncionario(-1, CiaAerea.getInstance().getViagens().buscarViagem(id).
						getComissario2().getId(), "Comiss�rio")).getProxViagens().remove(CiaAerea.getInstance().getViagens().buscarViagem(id));
				
				CiaAerea.getInstance().getViagens().removeViagem(id);
			
				JOptionPane.showMessageDialog(null, "Viagem removida com sucesso!", 
						"Remo��o de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
			}
		} else {
			throw new OpcaoInvalidaException();
		}
	}

	// Mostra o relat�rio de uma viagem cadastrada no sistema
	public void relatorioDeVoo() throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Viagens:\n" + CiaAerea.getInstance().getViagens().listarViagens() + 
				"\n\nDigite o ID da viagem que deseja exibir o relat�rio:\n\n", 
				"Relat�rio de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

		JOptionPane.showMessageDialog(null, CiaAerea.getInstance().getViagens().buscarViagem(id).relatorioDaViagem(), 
				"Relat�rio de Viagem - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
	}

}
