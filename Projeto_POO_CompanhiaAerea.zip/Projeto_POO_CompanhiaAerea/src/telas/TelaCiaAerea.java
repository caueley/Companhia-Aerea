package telas;

import javax.swing.JOptionPane;

import exceptions.NaoCadastradoException;
import exceptions.OpcaoInvalidaException;

import estrutura.CiaAerea;

import participantes.Pessoa;
import participantes.Cliente;
import participantes.Funcionario;

public class TelaCiaAerea {
	
	// ATRIBUTOS
	private static TelaCiaAerea objetoTelaCiaAerea;
	private Pessoa sessaoAtual;

	// M�TODOS CONSTRUTORES
	private TelaCiaAerea() {
		this.sessaoAtual = null;
	}

	public static TelaCiaAerea getInstance() {
		if(objetoTelaCiaAerea == null) {
			objetoTelaCiaAerea = new TelaCiaAerea();
		}
		return objetoTelaCiaAerea;
	}
	
	// M�TODOS MODIFICADORES
	public void setSessaoAtual(Pessoa sessaoAtual) {
		this.sessaoAtual = sessaoAtual;
	}
	
	public Pessoa getSessaoAtual() {
		return sessaoAtual;
	}

	// M�TODOS PERSONALIZADOS
	
	// Tela inicial do sistema.
	public int telaInicial() throws Exception {
		int opcao;
		opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Seja muito bem-vindo a " + CiaAerea.getInstance().getNome() + "!\n\n"
				+ "[1] Login\n[2] Novo Usu�rio\n[3] Informa��es da ABC AirLines\n[4] Encerrar Sistema\n\n", 
				CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

		if(opcao < 1 || opcao > 4) {
			throw new OpcaoInvalidaException();
		}
		return opcao;
	} 

	// Tela de login do sistema
	public void telaLogin() throws Exception {
		// O usu�rio informa se deseja fazer login utilizando uma conta de cliente ou funcion�rio
		int tipoLogin = Integer.parseInt(JOptionPane.showInputDialog(null, "Qual o tipo de acesso que deseja realizar?"
				+ "\n[1] Cliente\n[2] Funcion�rio\n[3] Voltar", CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

		// Usu�rio digita o seu usu�rio e senha 
		String usuario = null, senha = null;
		if(tipoLogin == 1 || tipoLogin == 2) {
			usuario = JOptionPane.showInputDialog(null, "Digite o usu�rio:", CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE);
			senha = JOptionPane.showInputDialog(null, "Digite a senha:", CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE);
		}
		
		switch(tipoLogin) {
		// Tentativa de logar em uma conta do tipo cliente
		case 1:
			setSessaoAtual(CiaAerea.getInstance().verificaLogin("Cliente", usuario, senha));
			if(getSessaoAtual() != null) {
				TelaCliente login = new TelaCliente((Cliente) getSessaoAtual());
				login.menu();
			} else {
				throw new NaoCadastradoException("cliente");
			}
			break;
		
		// Tentativa de logar em uma conta do tipo funcion�rio
		case 2:
			setSessaoAtual(CiaAerea.getInstance().verificaLogin("Funcion�rio", usuario, senha));
			if(getSessaoAtual() != null) {
				TelaFuncionario login = new TelaFuncionario((Funcionario) getSessaoAtual());
				login.telaFuncionario();
			} else {
				throw new NaoCadastradoException("funcion�rio(a)");
			}
			break;
		
		// Voltar para a p�gina anterior (tela inicial do sistema)
		case 3:
			break;
		
		// � selecionada uma op��o fora das dispon�veis
		default:
			throw new OpcaoInvalidaException();
		}
	}

	// Tela de cadastro de um novo cliente
	public void telaCadastroNovoUsuario() throws Exception {
		Cliente novoCliente = new Cliente();
		
		novoCliente.setNome();
		novoCliente.setDataDeNascimento();
		novoCliente.setCpf();
		novoCliente.setUsuario();
		novoCliente.setSenha();
		
		CiaAerea.getInstance().getClientes().adicionaCliente(novoCliente);
		
		TelaCliente login = new TelaCliente(novoCliente);
		login.menu();
	}

	// Mostrar informa��es sobre a Companhia A�rea
	public void telaInformacoesDaCompanhia() {
		JOptionPane.showMessageDialog(null, CiaAerea.getInstance().info(), 
				CiaAerea.getInstance().getNome() + " - Informa��es", JOptionPane.INFORMATION_MESSAGE);
	}

}
