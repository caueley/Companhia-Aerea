package telas;

import javax.swing.JOptionPane;

import exceptions.OpcaoInvalidaException;
import banco.Banco;
import estrutura.CiaAerea;

public class ProgramaPrincipal {
	public static void main(String[] args) {
		
		// Instanciando a Companhia A�rea
		CiaAerea abcAirLines = CiaAerea.getInstance();
		abcAirLines.setNome("ABC AirLines");
		abcAirLines.setCnpj("12.345.678/0001-90");
		abcAirLines.setFundacao(3, 6, 2019);
		abcAirLines.setLocalizacao("Santo Andr�-SP");
		
		// Instanciando o Banco
		Banco bancoDoABC = Banco.getInstance();
		
		// Instanciando a Interface do Sistema da Companhia A�rea
		TelaCiaAerea interfaceAbcAirLines = TelaCiaAerea.getInstance();
		
		// Come�o do Sistema
		int opcao = 0;
		do {
			try {
				opcao = interfaceAbcAirLines.telaInicial();
				switch(opcao) {
					case 1:
						interfaceAbcAirLines.telaLogin();
						break;
					case 2:
						interfaceAbcAirLines.telaCadastroNovoUsuario();
						break;
					case 3:
						interfaceAbcAirLines.telaInformacoesDaCompanhia();
						break;
					case 4:
						break;
					default:
						throw new OpcaoInvalidaException();
				}
			} catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Op��o Inv�lida", abcAirLines.getNome(), JOptionPane.ERROR_MESSAGE);
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), abcAirLines.getNome(), JOptionPane.ERROR_MESSAGE);
			} 
		} while(opcao != 4);	
	}
	
}
