package telas;

import javax.swing.JOptionPane;

import exceptions.OpcaoInvalidaException;
import exceptions.SemPassagensException;

import estrutura.CiaAerea;

import banco.Banco;

import participantes.Cliente;

public class TelaCliente {
	
	// ATRIBUTO
	private Cliente sessaoAtual;

	// M�TODO CONSTRUTOR
	public TelaCliente(Cliente sessaoAtual) {
		this.sessaoAtual = sessaoAtual;
	}
	
	// M�TODO MODIFICADOR
	private Cliente getSessaoAtual() {
		return sessaoAtual;
	}
	
	// M�TODOS PERSONALIZADOS
	
	// Menu principal do cliente
	public void menu() {
		int opcao = 0;
		do {
			try {
				opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Ol�, " + sessaoAtual.getNome() +
						"!\n\n[1] Buscar Passagem\n[2] Buscar Passagem  com Filtro\n[3] Comprar Passagem"
						+ "\n[4] Logout\n\n", "Cliente - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

				switch(opcao) {
				case 1:
					buscarPassagem();
					break;
				case 2:
					buscarPassagemAvancado();
					break;
				case 3:
					compraPassagem();
					break;
				case 4:
					int sair = JOptionPane.showConfirmDialog(null, "Deseja mesmo sair da sua conta?", "Cliente - Logout", JOptionPane.YES_NO_OPTION);
					if(sair == JOptionPane.NO_OPTION) opcao = 0;
					break;
				default:
					throw new OpcaoInvalidaException();
				}
			} catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Op��o Inv�lida", "Cliente - " + CiaAerea.getInstance().getNome(), JOptionPane.ERROR_MESSAGE);
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Cliente - " + CiaAerea.getInstance().getNome(), JOptionPane.ERROR_MESSAGE);
			}
		} while(opcao != 4);
	}

	// Lista de todos os voos cadastrados no sistema
	public void buscarPassagem() throws Exception {
		JOptionPane.showMessageDialog(null, "Viagens:\n" + CiaAerea.getInstance().getViagens().listarViagens(), 
				"Busca de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
	}

	// Lista de todos os voos cadastrados no sistema utilizando um filtro.
	public void buscarPassagemAvancado() throws Exception {
		int opcao = 0;
		do {
			try {
				opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja buscar viagem por: "
						+ "\n\n[1] Origem e Destino"
						+ "\n[2] Data"
						+ "\n[3] Hor�rio"
						+ "\n[4] Voltar\n\n", "Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

				switch(opcao) {
				case 1:
					String origem = JOptionPane.showInputDialog(null, "Insira a Origem:", 
							"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE);
					String destino = JOptionPane.showInputDialog(null, "Insira o Destino:", 
							"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE);
					
					JOptionPane.showMessageDialog(null, "Viagens de " + origem + " para " + destino + ":\n" +
							CiaAerea.getInstance().getViagens().listarViagensAvancado(origem, destino),  
							"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
					break;
				case 2:
					int hora = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira �s Horas:", 
							"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
					int minuto = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira os Minutos:", 
							"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
					
					JOptionPane.showMessageDialog(null, "Viagens �s " + CiaAerea.formatarHorario(0, 0, 0, hora, minuto) + ":\n" +
							CiaAerea.getInstance().getViagens().listarViagensAvancado(hora, minuto),  
							"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
					break;
				case 3:
					int dia = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira o Dia:", 
							"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
					int mes = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira o M�s:", 
							"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
					int ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira o Ano:", 
							"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
					JOptionPane.showMessageDialog(null, "Viagens no dia" + CiaAerea.formatarData(dia, mes, ano) + ":\n" +
							CiaAerea.getInstance().getViagens().listarViagensAvancado(dia, mes, ano),  
							"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
					break;
				case 4:
					break;
				default:
					throw new OpcaoInvalidaException();
				}
			} catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Op��o Inv�lida", 
						"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.ERROR_MESSAGE);	
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), 
						"Busca Avan�ada de Passagens - " + CiaAerea.getInstance().getNome(), JOptionPane.ERROR_MESSAGE);
			}
		} while(opcao != 4);
	}

	// Realizar a compra de uma passagem para um voo
	public void compraPassagem() throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Passagens:\n" 
				+ CiaAerea.getInstance().getViagens().listarViagens() + "\n\nDigite o ID da passagem que deseja comprar:", 
				"Compra de Passagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

		int numeroCartao = Integer.parseInt(JOptionPane.showInputDialog(null, "N�mero do cart�o:", 
				"Compra de Passagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));
		int senhaCartao = Integer.parseInt(JOptionPane.showInputDialog(null,"Senha:", 
				"Compra de Passagem - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

		if(CiaAerea.getInstance().getViagens().buscarViagem(id).getPassageiros().length - 
				CiaAerea.getInstance().getViagens().buscarViagem(id).getPassagensCompradas() > 0) {
			
			if(Banco.getInstance().autorizarCompra(numeroCartao, senhaCartao, CiaAerea.getInstance().getViagens().buscarViagem(id).getPreco())) {
				CiaAerea.getInstance().getViagens().buscarViagem(id).inserirPassageiro(getSessaoAtual());
				CiaAerea.getInstance().getViagens().buscarViagem(id).setPassagensCompradas();
				JOptionPane.showMessageDialog(null, "Passagem comprada com sucesso!", 
						"Compra de Passagem - " + CiaAerea.getInstance().getNome(), JOptionPane.INFORMATION_MESSAGE);
			}
		} else {
			throw new SemPassagensException();
		}
	}
	
}
