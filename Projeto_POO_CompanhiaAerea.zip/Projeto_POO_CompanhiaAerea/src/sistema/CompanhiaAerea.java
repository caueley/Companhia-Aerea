package sistema;

import estrutura.Informacoes;
import estrutura.ListaLigadaAviao;
import estrutura.ListaLigadaPessoa;
import estrutura.ListaLigadaViagens;

import participantes.Pessoa;
import participantes.Administrador;

public class CompanhiaAerea implements Informacoes {
	// ATRIBUTOS
	private String nome;
	private String cnpj;
	private String fundacao;
	private String localizacao;
	private ListaLigadaPessoa clientes;
	private ListaLigadaPessoa funcionarios;
	private ListaLigadaAviao avioes;
	private ListaLigadaViagens viagens;
	
	// M�TODO CONSTRUTOR
	public CompanhiaAerea(String nome, String cnpj, int fundacaoDia, int fundacaoMes, int fundacaoAno, String localizacao) {
		this.nome = nome;
		this.cnpj = cnpj;
		this.fundacao = InterfaceDoSistema.formatarData(fundacaoDia, fundacaoMes, fundacaoAno);
		this.localizacao = localizacao;
		
		clientes = new ListaLigadaPessoa();
		funcionarios = new ListaLigadaPessoa();
		avioes  = new ListaLigadaAviao();
		viagens = new ListaLigadaViagens();
		
		try {
			funcionarios.adicionaPessoa(new Administrador("Jo�o Pedro", 11, 12, 1996, "470.230.718-57", "joao.pereira", "adm123"));
		} catch(Exception e) {
		}
	}

	// M�TODOS MODIFICADORES
	public String getNome() {
		return nome;
	}
	
	public String getCnpj() {
		return cnpj;
	}

	public String getFundacao() {
		return fundacao;
	}

	public String getLocalizacao() {
		return localizacao;
	}

	public ListaLigadaPessoa getClientes() {
		return clientes;
	}
	
	public ListaLigadaPessoa getFuncionarios() {
		return funcionarios;
	}
	
	public ListaLigadaAviao getAvioes() {
		return avioes;
	}
	
	public ListaLigadaViagens getViagens() {
		return viagens;
	}

	// M�TODOS PERSONALIZADOS
	public void adicionaViagem(Pessoa pessoa) throws Exception {
	}
	
	public void removeViagem(Pessoa pessoa) throws Exception {
	}
	
	// Esse m�todo retorna as informa��es da companhia a�rea.
	@Override
	public String info() {
		return "Nome da Companhia: " + getNome() + "\nCNPJ: " + getCnpj() + 
				"\nFunda��o: " + getFundacao() + "\nLocaliza��o: " + getLocalizacao() + 
				"\nN� de Funcion�rios: " + (funcionarios.tamanhoDaLista()-1) + "\nN� de Clientes: " + clientes.tamanhoDaLista();
	}
	
	public Pessoa verificaLogin(String tipo, String usuario, String senha) {
		if(tipo.equals("Cliente")) {
			return clientes.verificaLogin(usuario, senha);
		} else {
			return funcionarios.verificaLogin(usuario, senha);
		}
	}
}

