package participantes;

import estrutura.Informacoes;

import sistema.InterfaceDoSistema;

public class Viagem implements Informacoes {
	// ATRIBUTOS
	private int id;
	private String origem;
	private String destino;
	private String data;
	private String horario;
	private Aviao aviao;
	private Piloto piloto;
	private Piloto copiloto;
	private Comissario comissario1;
	private Comissario comissario2;
	
	//M�TODO CONSTRUTOR
	public Viagem(String origem, String destino, int dia, int mes, int ano, int hora, int minuto,
			Aviao aviao, Piloto piloto, Piloto copiloto, Comissario comissario1, Comissario comissario2) {
		
		this.origem = origem;
		this.destino = destino;
		this.data = InterfaceDoSistema.formatarData(dia, mes, ano);
		this.horario = InterfaceDoSistema.formatarHorario(dia, mes, ano, hora, minuto);
		this.aviao = aviao;
		this.piloto = piloto;
		this.copiloto = copiloto;
		this.comissario1 = comissario1;
		this.comissario2 = comissario2;
	}
	
	// M�TODOS MODIFICADORES
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getOrigem() {
		return origem;
	}
	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}

	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}

	public String getHorario() {
		return horario;
	}
	public void setHorario(String horario) {
		this.horario = horario;
	}

	public Aviao getAviao() {
		return aviao;
	}
	public void setAviao(Aviao aviao) {
		this.aviao = aviao;
	}

	public Piloto getPiloto() {
		return piloto;
	}
	public void setPiloto(Piloto piloto) {
		this.piloto = piloto;
	}

	public Piloto getCopiloto() {
		return copiloto;
	}
	public void setCopiloto(Piloto copiloto) {
		this.copiloto = copiloto;
	}

	public Comissario getComissario1() {
		return comissario1;
	}
	public void setComissario1(Comissario comissario1) {
		this.comissario1 = comissario1;
	}

	public Comissario getComissario2() {
		return comissario2;
	}
	public void setComissario2(Comissario comissario2) {
		this.comissario2 = comissario2;
	}
	
	// Esse m�todo retorna as informa��es da viagem.
	@Override
	public String info() {
		return "\nID: " + getId() + "		Origem: " + getOrigem() + "		Destino: " + getDestino() + "Data: " + getData() +
				"Hor�rio: " + getHorario();
	}
	
}
