package participantes;

import java.util.Calendar;

import estrutura.CiaAerea;
import estrutura.Informacoes;

public class Viagem implements Informacoes {
	
	// ATRIBUTOS
	private int id;
	private String origem;
	private String destino;
	private String data;
	private String horario;
	private float preco;
	private Aviao aviao;
	private Piloto piloto;
	private Piloto copiloto;
	private Comissario comissario1;
	private Comissario comissario2;
	private Cliente[] passageiros;
	private int passagensCompradas;

	//M�TODO CONSTRUTOR
	public Viagem(String origem, String destino, int dia, int mes, int ano, int hora, int minuto, float preco,
			Aviao aviao, Piloto piloto, Piloto copiloto, Comissario comissario1, Comissario comissario2) {

		this.origem = origem;
		this.destino = destino;
		this.data = CiaAerea.formatarData(dia, mes, ano);
		this.horario = CiaAerea.formatarHorario(dia, mes, ano, hora, minuto);
		this.preco = preco;
		this.aviao = aviao;
		this.piloto = piloto;
		this.copiloto = copiloto;
		this.comissario1 = comissario1;
		this.comissario2 = comissario2;
		passageiros = new Cliente[aviao.getCapacidade()];
	}

	// M�TODOS MODIFICADORES
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOrigem() {
		return origem;
	}

	public String getDestino() {
		return destino;
	}

	public String getData() {
		return data;
	}

	public String getHorario() {
		return horario;
	}

	public float getPreco() {
		return preco;
	}

	public Aviao getAviao() {
		return aviao;
	}

	public Piloto getPiloto() {
		return piloto;
	}

	public Piloto getCopiloto() {
		return copiloto;
	}

	public Comissario getComissario1() {
		return comissario1;
	}

	public Comissario getComissario2() {
		return comissario2;
	}

	public Cliente[] getPassageiros() {
		return passageiros;
	}

	public int getPassagensCompradas() {
		return passagensCompradas;
	}

	public void setPassagensCompradas() {
		this.passagensCompradas += 1;
	}

	// M�TODOS PERSONALIZADOS
	
	// Insere na lista de passageiros um cliente que comprou uma passagem para a viagem.
	public void inserirPassageiro(Cliente novoPassageiro) {
		int i;
		for(i = 0; i < passageiros.length && passageiros[i] != null; i++);
		passageiros[i] = novoPassageiro;
	}

	// Retorna um relat�rio com diversas informa��es sobre a viagem
	public String relatorioDaViagem() {
		String titulo = "Relat�rio da Viagem:\n\n";
		String informacoesViagem = ">>> Informa��es da Viagem:\n\n"
				+ "ID: " + getId() + "\nOrigem: " + getOrigem() + "\nDestino: " + getDestino() + 
				"\nData: " + getData() + "\nHor�rio: " + getHorario() + "\nPassagens Compradas: " + getPassagensCompradas();
		String informacoesPassageiros = "\n\n>>> Informa��es dos Passageiros:\n";
		String listaDePassageiros = "";
		if(getPassagensCompradas() > 0) {
			for(int i = 0; i < getPassageiros().length && passageiros[i] != null ; i++) {
				if(passageiros[i] != null) {
					listaDePassageiros += passageiros[i].info();
				}
			}
		} else {
			listaDePassageiros = "\nAinda n�o h� passagens compradas para essa viagem.";
		}

		String informacoesFuncionarios = "\n\n>>>Informa��es dos Funcion�rios:\n" 
				+ getPiloto().info() + getCopiloto().info() + getComissario1().info() + getComissario2().info();

		Calendar hoje = Calendar.getInstance();
		String data = CiaAerea.formatarData(hoje.get(Calendar.DAY_OF_MONTH), hoje.get(Calendar.MONTH), hoje.get(Calendar.YEAR));
		String horario = CiaAerea.formatarHorario(0, 0, 0, hoje.get(Calendar.HOUR_OF_DAY), hoje.get(Calendar.MINUTE));

		String dataEHorario = "\n\nRelat�rio emitido em " + data + " �s " + horario + ".\n\n";

		return titulo + informacoesViagem + informacoesPassageiros + listaDePassageiros + informacoesFuncionarios + dataEHorario;
	}

	// Retorna as informa��es da viagem
	@Override
	public String info() {
		return "\nID: " + getId() + " \tOrigem: " + getOrigem() + " \tDestino: " + getDestino() + " \tData: " + getData() +
				" \tHor�rio: " + getHorario() + " \tPre�o: R$" + getPreco() + 
				" \tPassagens Restantes: " + (getPassageiros().length - getPassagensCompradas());
	}

}
