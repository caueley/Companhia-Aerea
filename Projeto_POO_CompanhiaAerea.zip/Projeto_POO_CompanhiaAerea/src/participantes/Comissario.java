package participantes;

import estrutura.ListaLigadaViagens;

public class Comissario extends Funcionario {
	// ATRIBUTOS
	private ListaLigadaViagens proxViagens;

	// M�TODO CONSTRUTOR
	public Comissario(String nomeCompleto, int diaNascimento, int mesNascimento, int anoNascimento, 
			String cpf, String usuario, String senha) {
		super(nomeCompleto, diaNascimento, mesNascimento, anoNascimento, cpf, "Comiss�rio", usuario, senha);
	}

	// M�TODO MODIFICADOR
	public ListaLigadaViagens getProxViagens() {
		return proxViagens;
	}
}
