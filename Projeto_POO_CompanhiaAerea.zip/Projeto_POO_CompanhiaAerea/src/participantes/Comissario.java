package participantes;

import java.util.ArrayList;

import exceptions.NadaCadastradoException;

public class Comissario extends Funcionario {

	// ATRIBUTO
	private ArrayList<Viagem> proxViagens;

	// M�TODO CONSTRUTOR
	public Comissario() {
		super("Comiss�rio");
		proxViagens = new ArrayList<Viagem>();
	}

	// M�TODO MODIFICADOR
	public ArrayList<Viagem> getProxViagens() {
		return proxViagens;
	}

	// M�TODO PERSONALIZADO
	public String listaViagens() throws Exception {
		String listaDeViagens = "";
		for(int i = 0; i < proxViagens.size(); i++) {
			listaDeViagens += proxViagens.get(i).info();
		}

		if(!listaDeViagens.isEmpty()) {
			return listaDeViagens;
		} else {
			throw new NadaCadastradoException("viagem");
		}
	}

}
