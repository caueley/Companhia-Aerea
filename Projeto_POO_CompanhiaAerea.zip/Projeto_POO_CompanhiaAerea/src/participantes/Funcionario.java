package participantes;

public abstract class Funcionario extends Pessoa {
	
	// ATRIBUTO
	private String cargo;
	
	// M�TODO CONSTRUTOR
	public Funcionario (String cargo) {
		this.cargo = cargo;
	}

	// M�TODO MODIFICADOR
	public String getCargo() {
		return cargo;
	}
	
	// M�TODOS PERSONALIZADOS
	
	// Informa��es do funcion�rio
	@Override
	public String info() {
		return super.info() + " \tCargo: " + getCargo();
	}
	
}
