package participantes;

public class Administrador extends Funcionario { 
	
	// M�TODO CONSTRUTOR
	public Administrador() {
		super("Administrador");
		setId(-1);
	}
	
}
