package participantes;

public class Cliente extends Pessoa {
	
}
