package participantes;

import javax.swing.JOptionPane;

import exceptions.OpcaoInvalidaException;
import exceptions.SemPassagensException;

import sistema.CompanhiaAerea;
import sistema.InterfaceDoSistema;

import banco.Banco;

public class Cliente extends Pessoa {
	// M�TODO CONSTRUTOR
	public Cliente (String nomeCompleto, int diaNascimento, int mesNascimento, int anoNascimento, 
			String cpf, String usuario, String senha) {
		super(nomeCompleto, diaNascimento, mesNascimento, anoNascimento, cpf, usuario, senha);
	}

	// Esse m�todo lista todos os voos cadastrados no sistema.
	public void buscarPassagem(CompanhiaAerea c) throws Exception {
		JOptionPane.showMessageDialog(null, "Viagens:\n" + c.getViagens().listarViagens(), "Busca de Passagens - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
	}

	// Esse m�todo lista todos os voos cadastrados no sistema utilizando um filtro.
	public void buscarPassagemAvancado(CompanhiaAerea c) throws Exception {
		int opcao = 0;
		do {
			try {
				opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Deseja buscar viagem por: "
						+ "\n\n[1] Origem e Destino"
						+ "\n[2] Data"
						+ "\n[3] Hor�rio"
						+ "\n[4] Voltar\n\n", "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));

				switch(opcao) {
				case 1:
					String origem = JOptionPane.showInputDialog(null, "Insira a Origem:", "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.QUESTION_MESSAGE);
					String destino = JOptionPane.showInputDialog(null, "Insira o Destino:", "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.QUESTION_MESSAGE);
					JOptionPane.showMessageDialog(null, "Viagens de " + origem + " para " + destino + ":\n\n" +
							c.getViagens().listarViagensAvancado(origem, destino),  "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
					break;
				case 2:
					int hora = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira �s Horas:", "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
					int minuto = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira os Minutos:", "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
					JOptionPane.showMessageDialog(null, "Viagens �s " + InterfaceDoSistema.formatarHorario(0, 0, 0, hora, minuto) + ":\n\n" +
							c.getViagens().listarViagensAvancado(hora, minuto),  "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
					break;
				case 3:
					int dia = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira o Dia:", "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
					int mes = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira o M�s:", "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
					int ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira o Ano:", "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
					JOptionPane.showMessageDialog(null, "Viagens no dia" + InterfaceDoSistema.formatarData(dia, mes, ano) + ":\n\n" +
							c.getViagens().listarViagensAvancado(dia, mes, ano),  "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
					break;
				case 4:
					break;
				default:
					throw new OpcaoInvalidaException();
				}
			} catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Op��o Inv�lida", "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.ERROR_MESSAGE);	
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Busca Avan�ada de Passagens - " + c.getNome(), JOptionPane.ERROR_MESSAGE);
			}
		} while(opcao != 4);
	}

	// Esse m�todo realiza a compra de uma passagem para um voo para o cliente.
	public void compraPassagem(CompanhiaAerea c, Banco sistemaBancario) throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Passagens:\n\n" 
				+ c.getViagens().listarViagens() + "\n\nDigite o ID da passagem que deseja comprar:", 
				"Compra de Passagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		
		int numeroCartao = Integer.parseInt(JOptionPane.showInputDialog(null, "N�mero do cart�o:", "Compra de Passagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		int senhaCartao = Integer.parseInt(JOptionPane.showInputDialog(null,"Senha:", "Compra de Passagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		
		if(c.getViagens().buscarViagem(id).getPassageiros().length - c.getViagens().buscarViagem(id).getPassagensCompradas() > 0) {
			if(sistemaBancario.autorizarCompra(numeroCartao, senhaCartao, c.getViagens().buscarViagem(id).getPreco())) {
				c.getViagens().buscarViagem(id).inserirPassageiro(this);
				c.getViagens().buscarViagem(id).setPassagensCompradas();
				JOptionPane.showMessageDialog(null, "Passagem comprada com sucesso!", "Compra de Passagem - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
			}
		} else {
			throw new SemPassagensException();
		}
	}

}