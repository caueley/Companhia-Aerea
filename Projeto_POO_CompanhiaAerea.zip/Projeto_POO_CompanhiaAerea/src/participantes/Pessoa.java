package participantes;

import javax.swing.JOptionPane;

import exceptions.ValorInvalidoException;
import exceptions.CampoEmBrancoException;

import estrutura.CiaAerea;
import estrutura.Informacoes;

public abstract class Pessoa implements Informacoes {
	
	// M�TODO PARA INICIALIZA��O DE USU�RIOS - PULAR PARA A LINHA 119

	/* Esse m�todo foi criado apenas para cadastrar alguns usu�rios sempre que o sistema for iniciado, para que n�o seja necess�rio
	 * cadastrar todos os usu�rios cada vez que ele � iniciado, j� que n�o h� persist�ncia dos dados introduzidos a cada execu��o */
	public static Pessoa[] criarUsuariosIniciais() {
		Pessoa[] vetor = new Pessoa[13];

		// Administrador Cadastrado
		vetor[0] = new Administrador();
		((Pessoa) vetor[0]).nome = "Jo�o Pedro";
		((Pessoa) vetor[0]).dataDeNascimento = CiaAerea.formatarData(11, 12, 1996);
		((Pessoa) vetor[0]).cpf = "123.456.789-00";
		((Pessoa) vetor[0]).usuario = "admin";
		((Pessoa) vetor[0]).senha = "admin";

		// Clientes Cadastrados
		vetor[1] = new Cliente();
		((Pessoa) vetor[1]).nome = "Carlos dos Santos";
		((Pessoa) vetor[1]).dataDeNascimento = CiaAerea.formatarData(14, 2, 1972);
		((Pessoa) vetor[1]).cpf = "123.456.789-01";
		((Pessoa) vetor[1]).usuario = "carlos.santos";
		((Pessoa) vetor[1]).senha = "123";

		vetor[2] = new Cliente();
		((Pessoa) vetor[2]).nome = "Rebeca Andrade";
		((Pessoa) vetor[2]).dataDeNascimento = CiaAerea.formatarData(22, 4, 1996);
		((Pessoa) vetor[2]).cpf = "123.456.789-02";
		((Pessoa) vetor[2]).usuario = "rebeca.andrade";
		((Pessoa) vetor[2]).senha = "123";

		vetor[3] = new Cliente();
		((Pessoa) vetor[3]).nome = "Vin�cius Teixeira";
		((Pessoa) vetor[3]).dataDeNascimento = CiaAerea.formatarData(1, 9, 1982);
		((Pessoa) vetor[3]).cpf = "123.456.789-03";
		((Pessoa) vetor[3]).usuario = "vinicius.teixeira";
		((Pessoa) vetor[3]).senha = "123";

		// Atendente Cadastrado
		vetor[4] = new Atendente();
		((Pessoa) vetor[4]).nome = "V�nia Matos";
		((Pessoa) vetor[4]).dataDeNascimento = CiaAerea.formatarData(1, 7, 1990);
		((Pessoa) vetor[4]).cpf = "123.456.789-04";
		((Pessoa) vetor[4]).usuario = "vania.matos";
		((Pessoa) vetor[4]).senha = "123";

		// Pilotos Cadastrados
		vetor[5] = new Piloto();
		((Pessoa) vetor[5]).nome = "Ricardo Abreu";
		((Pessoa) vetor[5]).dataDeNascimento = CiaAerea.formatarData(1, 7, 1990);
		((Pessoa) vetor[5]).cpf = "123.456.789-05";
		((Pessoa) vetor[5]).usuario = "ricardo.abreu";
		((Pessoa) vetor[5]).senha = "123";

		vetor[6] = new Piloto();
		((Pessoa) vetor[6]).nome = "Fl�via Monteiro";
		((Pessoa) vetor[6]).dataDeNascimento = CiaAerea.formatarData(1, 7, 1990);
		((Pessoa) vetor[6]).cpf = "123.456.789-06";
		((Pessoa) vetor[6]).usuario = "flavia.monteiro";
		((Pessoa) vetor[6]).senha = "123";

		vetor[7] = new Piloto();
		((Pessoa) vetor[7]).nome = "Gustavo Takashi";
		((Pessoa) vetor[7]).dataDeNascimento = CiaAerea.formatarData(1, 7, 1990);
		((Pessoa) vetor[7]).cpf = "123.456.789-07";
		((Pessoa) vetor[7]).usuario = "gustavo.takashi";
		((Pessoa) vetor[7]).senha = "123";

		vetor[8] = new Piloto();
		((Pessoa) vetor[8]).nome = "Maria Clara dos Santos";
		((Pessoa) vetor[8]).dataDeNascimento = CiaAerea.formatarData(1, 7, 1990);
		((Pessoa) vetor[8]).cpf = "123.456.789-08";
		((Pessoa) vetor[8]).usuario = "maria.santos";
		((Pessoa) vetor[8]).senha = "123";

		// Comiss�rios Cadastrados
		vetor[9] = new Comissario();
		((Pessoa) vetor[9]).nome = "D�bora Nascimento";
		((Pessoa) vetor[9]).dataDeNascimento = CiaAerea.formatarData(20, 1, 1985);
		((Pessoa) vetor[9]).cpf = "123.456.789-09";
		((Pessoa) vetor[9]).usuario = "debora.nascimento";
		((Pessoa) vetor[9]).senha = "123";
		
		vetor[10] = new Comissario();
		((Pessoa) vetor[10]).nome = "Henrique Monteiro";
		((Pessoa) vetor[10]).dataDeNascimento = CiaAerea.formatarData(14, 3, 1990);
		((Pessoa) vetor[10]).cpf = "123.456.789-10";
		((Pessoa) vetor[10]).usuario = "henrique.monteiro";
		((Pessoa) vetor[10]).senha = "123";
		
		vetor[11] = new Comissario();
		((Pessoa) vetor[11]).nome = "G�rson Freitas";
		((Pessoa) vetor[11]).dataDeNascimento = CiaAerea.formatarData(27, 11, 1988);
		((Pessoa) vetor[11]).cpf = "123.456.789-11";
		((Pessoa) vetor[11]).usuario = "gerson.freitas";
		((Pessoa) vetor[11]).senha = "123";
		
		vetor[12] = new Comissario();
		((Pessoa) vetor[12]).nome = "Talita Freitas";
		((Pessoa) vetor[12]).dataDeNascimento = CiaAerea.formatarData(18, 3, 1980);
		((Pessoa) vetor[12]).cpf = "123.456.789-12";
		((Pessoa) vetor[12]).usuario = "talita.freitas";
		((Pessoa) vetor[12]).senha = "123";

		return vetor;
	}

	// ATRIBUTOS
	private int id;
	private String nome;
	private String dataDeNascimento;
	private String cpf;
	private String usuario;
	private String senha;

	// M�TODOS MODIFICADORES
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setNome() {
		int validacao = 0;

		do {
			try {
				String nome = JOptionPane.showInputDialog(null, "Nome completo: ", "Cadastro de Usu�rio", JOptionPane.QUESTION_MESSAGE);

				if(nome.isEmpty()) {
					throw new CampoEmBrancoException();
				}

				this.nome = nome;
				validacao = 1;
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Cadastro de Usu�rio", JOptionPane.ERROR_MESSAGE);
			}
		} while(validacao == 0);
	}

	public String getNome() {
		return nome;
	}

	public void setDataDeNascimento() {
		int validacao = 0;

		do {
			try {
				Integer dia = Integer.parseInt(JOptionPane.showInputDialog(null, "Dia do nascimento: ", "Cadastro de Usu�rio", JOptionPane.QUESTION_MESSAGE));	
				int mes = Integer.parseInt(JOptionPane.showInputDialog(null, "M�s do nascimento: ", "Cadastro de Usu�rio", JOptionPane.QUESTION_MESSAGE));
				int ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Ano do nascimento: ", "Cadastro de Usu�rio", JOptionPane.QUESTION_MESSAGE));

				if(verificaAno(ano) && verificaMes(mes) && verificaDia(dia, mes)) {
					this.dataDeNascimento = CiaAerea.formatarData(dia, mes, ano);
					validacao = 1;
				} else {
					throw new ValorInvalidoException("data");
				}
			} catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Preencha o campo corretamente!", "Cadastro de Usu�rio", JOptionPane.ERROR_MESSAGE);
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Cadastro de Usu�rio", JOptionPane.ERROR_MESSAGE);
			}
		} while(validacao == 0);
	}

	private boolean verificaAno(int ano) {
		if(ano <= CiaAerea.anoAtual()) {
			return true;
		} else {
			return false;
		}
	}

	private boolean verificaMes(int mes) {
		if(mes >= 1 && mes <= 12) {
			return true;
		} else {
			return false;
		}
	}

	private boolean verificaDia(int dia, int mes) {
		if(mes == 2 && dia <= 28) {
			return true;
		} else {
			if((mes == 1 || mes == 3 || mes == 5 || mes == 7 || mes == 8 || mes ==10 || mes == 12) && dia <= 31) {
				return true;
			} else {
				if((mes == 4 || mes == 6 || mes == 9 || mes == 11) && dia <= 30) {
					return true;
				} else {
					return false;
				}
			}
		}
	}

	public String getDataDeNascimento() {
		return dataDeNascimento;
	}

	public void setCpf() {
		int validacao = 0;

		do {
			try {
				String cpf = JOptionPane.showInputDialog(null, "CPF: ", "Cadastro de Usu�rio", JOptionPane.QUESTION_MESSAGE);

				if(cpf.isEmpty()) {
					throw new CampoEmBrancoException();
				}

				this.cpf = cpf;
				validacao = 1;
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Cadastro de Usu�rio", JOptionPane.ERROR_MESSAGE);
			}
		} while(validacao == 0);
	}

	public String getCpf() {
		return cpf;
	}

	public void setUsuario() {
		int validacao = 0;

		do {
			try {
				String usuario = JOptionPane.showInputDialog(null, "Usu�rio para acesso o sistema: ", "Cadastro de Usu�rio", JOptionPane.QUESTION_MESSAGE);

				if(usuario.isEmpty()) {
					throw new CampoEmBrancoException();
				}

				this.usuario = usuario;
				validacao = 1;
			} catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Cadastro de Usu�rio", JOptionPane.ERROR_MESSAGE);
			}
		} while(validacao == 0);
	}

	public String getUsuario() {
		return usuario;
	}

	public void setSenha() {
		int validacao = 0;

		do {
			try {
				String senha = JOptionPane.showInputDialog(null, "Senha para acesso o sistema: ", "Cadastro de Usu�rio", JOptionPane.QUESTION_MESSAGE);

				if(senha.isEmpty()) {
					throw new CampoEmBrancoException();
				}

				this.senha = senha;
				validacao = 1;
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Cadastro de Usu�rio", JOptionPane.ERROR_MESSAGE);
			}
		} while(validacao == 0);
	}

	public String getSenha() {
		return senha;
	}

	// M�TODOS PERSONALIZADOS

	// Retorna as informa��es da pessoa.
	@Override
	public String info() {
		return "\nID: " + getId() + " \tNome: " + getNome() + " \tCPF: " + getCpf();
	}

}
