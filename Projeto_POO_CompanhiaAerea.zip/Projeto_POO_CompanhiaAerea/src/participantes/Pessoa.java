package participantes;

import estrutura.Informacoes;

public abstract class Pessoa implements Informacoes {
	// ATRIBUTOS
	private int id;
	private String nomeCompleto;
	private String dataDeNascimento;
	private String cpf;
	private int milhas;
	private String usuario;
	private String senha;

	// M�TODO CONSTRUTOR
	public Pessoa(String nomeCompleto, int diaNascimento, int mesNascimento, 
			int anoNascimento, String cpf, String usuario, String senha) {
		this.nomeCompleto = nomeCompleto;
		this.dataDeNascimento = diaNascimento + "/" + mesNascimento + "/" + anoNascimento;
		this.cpf = cpf;
		this.usuario = usuario;
		this.senha = senha;
		this.milhas = 0;
	}

	// M�TODOS MODIFICADORES
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getNomeCompleto() {
		return nomeCompleto;
	}
	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	public String getDataDeNascimento() {
		return dataDeNascimento;
	}
	public void setDataDeNascimento(String dataDeNascimento) {
		this.dataDeNascimento = dataDeNascimento;
	}

	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}

	public int getMilhas() {
		return milhas;
	}
	public void setMilhas(int milhas) {
		this.milhas = milhas;
	}

	// Esse m�todo retorna as informa��es da pessoa.
	@Override
	public String info() {
		return "\nID: " + getId() + "     Nome: " + getNomeCompleto() + "     CPF: " + getCpf();
	}

}
