package participantes;

import estrutura.AdicionaViagem;
import estrutura.ListaLigadaViagens;

public class Piloto extends Funcionario implements AdicionaViagem {
	// ATRIBUTOS
	private ListaLigadaViagens proxViagens;

	// M�TODO CONSTRUTOR
	public Piloto(String nomeCompleto, int diaNascimento, int mesNascimento, int anoNascimento, 
			String cpf, String usuario, String senha) {
		super(nomeCompleto, diaNascimento, mesNascimento, anoNascimento, cpf, "Piloto", usuario, senha);
	}

	// M�TODO MODIFICADOR
	public ListaLigadaViagens getProxViagens() {
		return proxViagens;
	}
	
	// Esse m�todo adiciona uma viagem na lista das viagens que o piloto ir� trabalhar.
	@Override
	public void adicionarViagem(Viagem v) throws Exception {
		getProxViagens().adicionaViagem(v);
	}
	
}
