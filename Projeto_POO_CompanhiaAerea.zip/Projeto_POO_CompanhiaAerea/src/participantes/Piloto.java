package participantes;

import estrutura.ListaLigadaViagens;

public class Piloto extends Funcionario {
	// ATRIBUTOS
	private ListaLigadaViagens proxViagens;

	// M�TODO CONSTRUTOR
	public Piloto(String nomeCompleto, int diaNascimento, int mesNascimento, int anoNascimento, 
			String cpf, String usuario, String senha) {
		super(nomeCompleto, diaNascimento, mesNascimento, anoNascimento, cpf, "Piloto", usuario, senha);
	}

	// M�TODO MODIFICADOR
	public ListaLigadaViagens getProxViagens() {
		return proxViagens;
	}
}
