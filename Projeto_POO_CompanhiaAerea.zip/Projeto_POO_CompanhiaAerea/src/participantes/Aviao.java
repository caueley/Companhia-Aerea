package participantes;

import javax.swing.JOptionPane;

import exceptions.CampoEmBrancoException;
import exceptions.ValorInvalidoException;

import estrutura.CiaAerea;
import estrutura.Informacoes;

public class Aviao implements Informacoes {
	
	// M�TODO PARA INICIALIZA��O DE AVI�ES - PULAR PARA A LINHA 44
	
	/* Esse m�todo foi criado apenas para cadastrar alguns avi�es sempre que o sistema for iniciado, para que n�o seja necess�rio
	 * cadastrar todos os avi�es cada vez que ele � iniciado, j� que n�o h� persist�ncia dos dados introduzidos a cada execu��o */
	public static Aviao[] criarAvioesIniciais() {
		Aviao[] vetor = new Aviao[5];
		
		// Avi�es Cadastrados
		vetor[0] = new Aviao();
		vetor[0].modelo = "Airbus";
		vetor[0].capacidade = 150;
		
		vetor[1] = new Aviao();
		vetor[1].modelo = "Airbus";
		vetor[1].capacidade = 120;
		
		vetor[2] = new Aviao();
		vetor[2].modelo = "Airbus";
		vetor[2].capacidade = 120;
		
		vetor[3] = new Aviao();
		vetor[3].modelo = "Boeing";
		vetor[3].capacidade = 300;
		
		vetor[4] = new Aviao();
		vetor[4].modelo = "Boeing";
		vetor[4].capacidade = 300;
		
		return vetor;
	}

	// ATRIBUTOS
	private int id;
	private String modelo;
	private int capacidade;

	// M�TODOS MODIFICADORES
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setModelo() {
		int validacao = 0;
		do {
			try {
				String modelo = JOptionPane.showInputDialog(null, "Insira o modelo do avi�o:", 
						"Cadastro de Avi�o - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE);

				if(modelo.isEmpty()) {
					throw new CampoEmBrancoException();
				}

				this.modelo = modelo;
				validacao = 1;
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Cadastro de Avi�o - " + CiaAerea.getInstance().getNome(), JOptionPane.ERROR_MESSAGE);
			}
		} while(validacao == 0);
	}

	public String getModelo() {
		return modelo;
	}

	public int getCapacidade() {
		return capacidade;
	}

	public void setCapacidade() {
		int validacao = 0;

		do {
			try {
				int capacidade = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira a capacidade do avi�o: ", 
						"Cadastro de Avi�o - " + CiaAerea.getInstance().getNome(), JOptionPane.QUESTION_MESSAGE));

				if(capacidade > 0) {
					this.capacidade = capacidade;
					validacao = 1;
				} else {
					throw new ValorInvalidoException("capacidade");
				}
			} catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Capacidade n�o permitida!", 
						"Cadastro de Avi�o - " + CiaAerea.getInstance().getNome(), JOptionPane.ERROR_MESSAGE);
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), "Cadastro de Avi�o - " + CiaAerea.getInstance().getNome(), JOptionPane.ERROR_MESSAGE);
			}
		} while(validacao == 0);
	}

	// M�TODO PERSONALIZADO

	// Informa��es do avi�o
	@Override
	public String info() {
		return "\nID: " + getId() + " \tModelo: " + getModelo() + " \tCapacidade: " + getCapacidade();
	}

}
