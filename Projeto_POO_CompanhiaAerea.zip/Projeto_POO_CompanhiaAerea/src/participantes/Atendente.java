package participantes;

public class Atendente extends Funcionario {
	
	// M�TODO CONSTRUTOR
	public Atendente() {
		super("Atendente");
	}
	
}
