package participantes;

import javax.swing.JOptionPane;

import exceptions.OpcaoInvalidaException;

import sistema.CompanhiaAerea;

public class Atendente extends Funcionario {
	// M�TODO CONSTRUTOR
	public Atendente(String nomeCompleto, int diaNascimento, int mesNascimento, int anoNascimento, 
			String cpf, String usuario, String senha) {
		super(nomeCompleto, diaNascimento, mesNascimento, anoNascimento, cpf, "Atendente", usuario, senha);
	}

	// Esse m�todo adiciona uma nova viagem a lista de viagens cadastradas no sistema.
	public void adicionaViagem(CompanhiaAerea c) throws Exception {
		String origem = JOptionPane.showInputDialog(null, "Origem: ", "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE);
		String destino = JOptionPane.showInputDialog(null, "Destino: ", "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE);
		int dia = Integer.parseInt(JOptionPane.showInputDialog(null, "Dia: ", "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		int mes = Integer.parseInt(JOptionPane.showInputDialog(null, "M�s: ", "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		int ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Ano: ", "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		int hora = Integer.parseInt(JOptionPane.showInputDialog(null, "Hora: ", "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		int minuto = Integer.parseInt(JOptionPane.showInputDialog(null, "Minuto: ", "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		int preco = Integer.parseInt(JOptionPane.showInputDialog(null, "Pre�o (em reais): ", "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		
		int idAviao = Integer.parseInt(JOptionPane.showInputDialog(null, "Avi�es Cadastrados:\n\n"
				+ c.getAvioes().listarAvioes() + "\n\nInsira o ID do avi�o que deseja selecionar para essa viagem:"
				, "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		Aviao aviao = c.getAvioes().buscarAviao(idAviao);

		int idPiloto = Integer.parseInt(JOptionPane.showInputDialog(null, "Pilotos Cadastrados:\n\n"
				+ c.getFuncionarios().listarPilotos(0) + "\n\nInsira o ID do Piloto que deseja selecionar para essa viagem:"
				, "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		Piloto piloto = (Piloto) c.getFuncionarios().buscarFuncionario(0, idPiloto, "Piloto");

		int idCopiloto = Integer.parseInt(JOptionPane.showInputDialog(null, "Copilotos Cadastrados:\n\n"
				+ c.getFuncionarios().listarPilotos(idPiloto) + "\n\nInsira o ID do Copiloto que deseja selecionar para essa viagem:"
				, "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		Piloto copiloto = (Piloto) c.getFuncionarios().buscarFuncionario(idPiloto, idCopiloto, "Piloto");

		int idComissario1 = Integer.parseInt(JOptionPane.showInputDialog(null, "Comiss�rios Cadastrados:\n\n"
				+ c.getFuncionarios().listarComissarios(0) + "\n\nInsira o ID do Comiss�rio que deseja selecionar para essa viagem:"
				, "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		Comissario comissario1 = (Comissario) c.getFuncionarios().buscarFuncionario(0, idComissario1, "Comiss�rio");

		int idComissario2 = Integer.parseInt(JOptionPane.showInputDialog(null, "Comiss�rios Cadastrados:\n\n"
				+ c.getFuncionarios().listarComissarios(idComissario1) + "\n\nInsira o ID do Comiss�rio que deseja selecionar para essa viagem:"
				, "Cadastro de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		Comissario comissario2 = (Comissario) c.getFuncionarios().buscarFuncionario(idComissario1, idComissario2, "Comiss�rio");
		
		Viagem novaViagem = new Viagem(origem, destino, dia, mes, ano, hora, minuto, preco, aviao, piloto, copiloto, comissario1, comissario2);
		c.getViagens().adicionaViagem(novaViagem);
		
		JOptionPane.showMessageDialog(null, "Viagem cadastrada com sucesso!", "Cadastro de Viagem - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
	}

	/* Esse m�todo remove uma viagem da lista de viagens cadastradas no sistema. Por�m, s� � poss�vel excluir essa viagem caso n�o tenham sido vendidas
	 * 50% ou mais das passagens disponiblizadas para este voo. */
	public void removeViagem(CompanhiaAerea c) throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Viagens:\n" + c.getViagens().listarViagens() + 
				"\n\nDigite o ID da viagem que deseja remover:\n\n", "Remo��o de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));

		if(c.getViagens().buscarViagem(id).getPassagensCompradas() < c.getAvioes().buscarAviao(c.getViagens().buscarViagem(id).getAviao().getId()).getCapacidade()/2) {
			int opcao = JOptionPane.showConfirmDialog(null, "Deseja mesmo remover essa viagem?", "Remo��o de Viagem - " + c.getNome(), JOptionPane.YES_NO_OPTION);

			if(opcao == JOptionPane.YES_OPTION) {
				c.getViagens().removeViagem(id);
				JOptionPane.showMessageDialog(null, "Viagem removida com sucesso!", "Remo��o de Viagem - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
			}
		} else {
			throw new OpcaoInvalidaException();
		}
	}

	/*Esse m�todo imprime para o atendente um relat�rio do voo, com as especifica��es do voo, as informa��es dos passageiros e dos funcionarios que trabalhar�o
	 * nele.*/
	public void relatorioDeVoo(CompanhiaAerea c) throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Viagens:\n" + c.getViagens().listarViagens() + 
				"\n\nDigite o ID da viagem que deseja exibir o relat�rio:\n\n", "Relat�rio de Viagem - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		JOptionPane.showMessageDialog(null, c.getViagens().buscarViagem(id).relatorioDaViagem(), 
				"Relat�rio de Viagem - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
	}
	
}
