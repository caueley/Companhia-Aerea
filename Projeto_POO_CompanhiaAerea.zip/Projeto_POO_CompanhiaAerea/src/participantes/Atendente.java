package participantes;

public class Atendente extends Funcionario {
	// M�TODO CONSTRUTOR
	public Atendente(String nomeCompleto, int diaNascimento, int mesNascimento, int anoNascimento, 
			String cpf, String usuario, String senha) {
		super(nomeCompleto, diaNascimento, mesNascimento, anoNascimento, cpf, "Atendente", usuario, senha);
	}
}
