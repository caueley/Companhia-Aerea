package banco;

public class Correntista {
	private String nome;
	private int numeroCartao;
	private int senhaCartao;
	private float saldo;
	
	public Correntista(String nome, int senhaCartao, float saldo) {
		this.nome = nome;
		this.senhaCartao = senhaCartao;
		this.saldo = saldo;
	}
	
	public void setNumeroCartao(int numeroCartao) {
		this.numeroCartao = numeroCartao;
	}
	
	public int getNumeroCartao() {
		return numeroCartao;
	}
	
	public int getSenhaCartao() {
		return senhaCartao;
	}
	
	public void setSaldo(float valorGasto) {
		this.saldo -= valorGasto;
	}
	
	public float getSaldo() {
		return saldo;
	}
}
