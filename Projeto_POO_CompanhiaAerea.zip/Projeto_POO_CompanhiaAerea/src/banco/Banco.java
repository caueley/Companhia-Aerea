package banco;

import exceptions.BancoNaoAutorizouException;

public class Banco {
	// ATRIBUTOS
	private String nomeBanco;
	private ListaLigadaBanco correntistas;

	// M�TODO CONSTRUTOR
	public Banco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
		correntistas = new ListaLigadaBanco();
		
		// Correntistas Cadastrados
		correntistas.adicionaCorrentista(new Correntista("Carlos dos Santos", 123, 8000));
		correntistas.adicionaCorrentista(new Correntista("Rebeca Andrade", 123, 200));
		correntistas.adicionaCorrentista(new Correntista("Vin�cius Teixeira", 123, 3000));
		correntistas.adicionaCorrentista(new Correntista("Antonio Carlos Macedo", 123, 5000));
		correntistas.adicionaCorrentista(new Correntista("Giovanna Garc�a", 123, 7500));
		correntistas.adicionaCorrentista(new Correntista("Lucas Matos", 123, 0));
		correntistas.adicionaCorrentista(new Correntista("Lu�sa Garc�a", 123, 10000));
		correntistas.adicionaCorrentista(new Correntista("Guilherme da Silva", 123, 600));
		correntistas.adicionaCorrentista(new Correntista("Giuliana Pereira", 123, 1000));
		correntistas.adicionaCorrentista(new Correntista("J�lia Neves", 123, 32000));
	}

	// M�TODO MODIFICADOR
	public ListaLigadaBanco getCorrentistas() throws Exception {
		return correntistas;
	}

	public boolean autorizarCompra(int numeroCartao, int senhaCartao, float valor) throws Exception {
		if(getCorrentistas().verificaNumeroESenha(numeroCartao, senhaCartao)) {
			if(getCorrentistas().buscarClienteBanco(numeroCartao, senhaCartao).getSaldo() >= valor) {
				getCorrentistas().buscarClienteBanco(numeroCartao, senhaCartao).setSaldo(valor);
				return true;
			} else {
				throw new BancoNaoAutorizouException();
			}
		} else {
			throw new BancoNaoAutorizouException();
		}
	}

}
