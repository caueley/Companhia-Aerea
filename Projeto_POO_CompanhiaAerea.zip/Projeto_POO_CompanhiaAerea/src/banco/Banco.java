package banco;

import exceptions.BancoNaoAutorizouException;

public class Banco {
	// ATRIBUTOS
	private String nomeBanco;
	private ListaLigadaBanco correntistas;

	// M�TODO CONSTRUTOR
	public Banco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
		correntistas = new ListaLigadaBanco();
		
		/* Como o foco era construir o sistema de reserva de passagens a�reas, foi feita uma implementa��o b�sica de um sistema banc�rio, apenas
		 * para armazenar um correntista e as informa��es de numero do cart�o, senha e saldo banc�rio dele, por isso n�o houve nem a implementa��o
		 * de um m�todo para cadastrar correntistas, sendo eles cadastrados diretamente no c�digo. */
		
		// Correntistas Cadastrados
		correntistas.adicionaCorrentista(new Correntista("Carlos dos Santos", 123, 8000));
		correntistas.adicionaCorrentista(new Correntista("Rebeca Andrade", 123, 200));
		correntistas.adicionaCorrentista(new Correntista("Vin�cius Teixeira", 123, 3000));
		correntistas.adicionaCorrentista(new Correntista("Antonio Carlos Macedo", 123, 5000));
		correntistas.adicionaCorrentista(new Correntista("Giovanna Garc�a", 123, 7500));
		correntistas.adicionaCorrentista(new Correntista("Lucas Matos", 123, 0));
		correntistas.adicionaCorrentista(new Correntista("Lu�sa Garc�a", 123, 10000));
		correntistas.adicionaCorrentista(new Correntista("Guilherme da Silva", 123, 600));
		correntistas.adicionaCorrentista(new Correntista("Giuliana Pereira", 123, 1000));
		correntistas.adicionaCorrentista(new Correntista("J�lia Neves", 123, 32000));
	}

	// M�TODO MODIFICADOR
	public ListaLigadaBanco getCorrentistas() throws Exception {
		return correntistas;
	}

	// Esse m�todo retorna para o sistema da companhia a�rea se a transa��o foi realizada ou se houve algum problema.
	public boolean autorizarCompra(int numeroCartao, int senhaCartao, float valor) throws Exception {
		if(getCorrentistas().verificaNumeroESenha(numeroCartao, senhaCartao)) {
			if(getCorrentistas().buscarClienteBanco(numeroCartao, senhaCartao).getSaldo() >= valor) {
				getCorrentistas().buscarClienteBanco(numeroCartao, senhaCartao).setSaldo(valor);
				return true;
			} else {
				throw new BancoNaoAutorizouException();
			}
		} else {
			throw new BancoNaoAutorizouException();
		}
	}

}
