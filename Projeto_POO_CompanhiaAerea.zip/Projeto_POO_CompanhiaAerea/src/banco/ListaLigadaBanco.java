package banco;

import exceptions.BancoNaoAutorizouException;

public class ListaLigadaBanco {
	private class LinkedNode {
		private Correntista data;
		private LinkedNode next;
	}

	private LinkedNode first;

	public void adicionaCorrentista(Correntista correntista) {
		LinkedNode novoCorrentista = new LinkedNode();
		novoCorrentista.data = correntista;
		novoCorrentista.next = null;

		if(first == null) {
			novoCorrentista.data.setNumeroCartao(1);
			this.first = novoCorrentista;
		} else {
			LinkedNode anterior = null;
			LinkedNode atual = first;
			int numeroCartao = 0;

			while(atual != null) {
				if(atual != null) {
					numeroCartao = atual.data.getNumeroCartao();
				}
				anterior = atual;
				atual = atual.next;
			}
			novoCorrentista.data.setNumeroCartao(numeroCartao+1);
			anterior.next = novoCorrentista;
		}
	}
	
	public boolean verificaNumeroESenha(int numeroCartao, int senhaCartao) {
		LinkedNode node = first;
		
		while(node != null && (node.data.getNumeroCartao() != numeroCartao || node.data.getSenhaCartao() != senhaCartao)) {
			node = node.next;
		}
		
		if(node != null) {
			return true;
		} else {
			return false;
		}
	}
	
	public Correntista buscarClienteBanco(int numeroCartao, int senhaCartao) throws Exception {
		LinkedNode node = first;
		
		while(node != null && (node.data.getNumeroCartao() != numeroCartao || node.data.getSenhaCartao() != senhaCartao)) {
			node = node.next;
		}
		
		if(node != null) {
			return node.data;
		} else {
			throw new BancoNaoAutorizouException();
		}
	}
	
}
