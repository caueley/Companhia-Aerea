package exceptions;

public class ValorInvalidoException extends Exception {
	public ValorInvalidoException(String palavra) {
		super("Valor de " + palavra + " inv�lido!");
	}
}
