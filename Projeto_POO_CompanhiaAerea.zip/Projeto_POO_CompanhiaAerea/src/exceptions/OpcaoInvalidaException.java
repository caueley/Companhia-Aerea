package exceptions;

public class OpcaoInvalidaException extends Exception {
	public OpcaoInvalidaException() {
		super("Op��o Inv�lida!");
	}
}
