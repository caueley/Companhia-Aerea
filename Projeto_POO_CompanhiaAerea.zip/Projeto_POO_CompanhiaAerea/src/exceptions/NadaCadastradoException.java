package exceptions;

public class NadaCadastradoException extends Exception {
	public NadaCadastradoException(String palavra) {
		super("N�o h� nenhum(a) " + palavra + " cadastrado(a)!");
	}
}
