package exceptions;

public class CampoEmBrancoException extends Exception {
	public CampoEmBrancoException() {
		super("O preenchimento deste campo � obrigat�rio!");
	}
}
