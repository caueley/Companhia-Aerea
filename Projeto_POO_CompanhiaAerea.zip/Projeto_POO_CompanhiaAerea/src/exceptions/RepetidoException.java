package exceptions;

public class RepetidoException extends Exception{
	public RepetidoException(String palavra) {
		super("J� h� uma pessoa cadastrada no sistema com este " + palavra + ".");
	}
}
