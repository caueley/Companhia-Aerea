package exceptions;

public class NaoCadastradoException extends Exception {
	public NaoCadastradoException(String palavra) {
		super("N�o h� nenhum(a) " + palavra + " cadastrado(a) com esse ID.");
	}
}
