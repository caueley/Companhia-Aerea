package exceptions;

public class SemPassagensException extends Exception {
	public SemPassagensException() {
		super("N�o h� mais passagens dispon�veis para esse v�o.");
	}
	
}
