package exceptions;

public class BancoNaoAutorizouException extends Exception {
	public BancoNaoAutorizouException() {
		super("O banco n�o autorizou a compra da passagem!");
	}
}
