package participantes;

import exceptions.ValorInvalidoException;

import estrutura.Informacoes;

public class Aviao implements Informacoes {
	// ATRIBUTOS
	private int id;
	private String modelo;
	private Viagem proxViagem;
	private int capacidade;

	// M�TODO CONSTRUTOR
	public Aviao(String modelo, int capacidade) {
		this.modelo = modelo;
		this.capacidade = capacidade;
	}

	// M�TODOS MODIFICADORES
	public int getId() {
		return id;
	}	
	public void setId(int id) {
		this.id = id;
	}

	public String getModelo() {
		return modelo;
	}

	public Viagem getProxViagem() {
		return proxViagem;
	}
	public void setProxViagem(Viagem proxViagem) {
		this.proxViagem = proxViagem;
	}

	public int getCapacidade() {
		return capacidade;
	}
	public void setCapacidade(int capacidade) throws Exception {
		if(capacidade > 0) {
			this.capacidade = capacidade;
		} else {
			throw new ValorInvalidoException("capacidade");
		}
	}

	// Esse m�todo retorna as informa��es do avi�o.
	@Override
	public String info() {
		return "\nID" + getId() + "	Modelo: " + getModelo() + "		Capacidade: " + getCapacidade();
	}
	
}
