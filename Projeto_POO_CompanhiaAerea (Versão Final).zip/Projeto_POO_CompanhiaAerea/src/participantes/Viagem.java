package participantes;

import estrutura.Informacoes;

import sistema.InterfaceDoSistema;

public class Viagem implements Informacoes {
	// ATRIBUTOS
	private int id;
	private String origem;
	private String destino;
	private String data;
	private String horario;
	private float preco;
	private Aviao aviao;
	private Piloto piloto;
	private Piloto copiloto;
	private Comissario comissario1;
	private Comissario comissario2;
	private Cliente[] passageiros;
	private int passagensCompradas;

	//M�TODO CONSTRUTOR
	public Viagem(String origem, String destino, int dia, int mes, int ano, int hora, int minuto, float preco,
			Aviao aviao, Piloto piloto, Piloto copiloto, Comissario comissario1, Comissario comissario2) {

		this.origem = origem;
		this.destino = destino;
		this.data = InterfaceDoSistema.formatarData(dia, mes, ano);
		this.horario = InterfaceDoSistema.formatarHorario(dia, mes, ano, hora, minuto);
		this.preco = preco;
		this.aviao = aviao;
		this.piloto = piloto;
		this.copiloto = copiloto;
		this.comissario1 = comissario1;
		this.comissario2 = comissario2;
		passageiros = new Cliente[aviao.getCapacidade()];
	}

	// M�TODOS MODIFICADORES
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	public String getOrigem() {
		return origem;
	}

	public String getDestino() {
		return destino;
	}

	public String getData() {
		return data;
	}

	public String getHorario() {
		return horario;
	}

	public float getPreco() {
		return preco;
	}
	
	public Aviao getAviao() {
		return aviao;
	}

	public Piloto getPiloto() {
		return piloto;
	}

	public Piloto getCopiloto() {
		return copiloto;
	}

	public Comissario getComissario1() {
		return comissario1;
	}

	public Comissario getComissario2() {
		return comissario2;
	}

	public Cliente[] getPassageiros() {
		return passageiros;
	}

	public int getPassagensCompradas() {
		return passagensCompradas;
	}

	public void setPassagensCompradas() {
		this.passagensCompradas += 1;
	}

	/* Esse m�todo retorna um relat�rio com diversas informa��es sobre essa viagem, como a descri��o da viagem, os passageiros que at�
	 * o momento em que foi gerado o relat�rio compraram passagem para estarem neste voo, al�m dos funcion�rios que trabalharam nele. */
	public String relatorioDaViagem() {
		String titulo = "Relat�rio da Viagem:\n\n";
		String informacoesViagem = ">>> Informa��es da Viagem:\n\n"
				+ "ID: " + getId() + "\nOrigem: " + getOrigem() + "\nDestino: " + getDestino() + 
				"\nData: " + getData() + "\nHor�rio: " + getHorario() + "\nPassagens Compradas: " + getPassagensCompradas();
		String informacoesPassageiros = "\n\n>>> Informa��es dos Passageiros:\n\n";
		String listaDePassageiros = "";
		if(getPassagensCompradas() > 0) {
			for(int i = 0; i < getPassageiros().length && passageiros[i] != null ; i++) {
				if(passageiros[i] != null) {
					listaDePassageiros += passageiros[i].info();
				}
			}
		} else {
			listaDePassageiros = "Ainda n�o h� passagens compradas para essa viagem.";
		}

		String informacoesFuncionarios = "\n\n>>>Informa��es dos Funcion�rios:\n\n" 
				+ getPiloto().info() + getCopiloto().info() + getComissario1().info() + getComissario2().info();

		return titulo + informacoesViagem + informacoesPassageiros + listaDePassageiros + informacoesFuncionarios;
	}

	// Esse m�todo insere na lista de passageiros um cliente que comprou uma passagem para essa viagem.
	public void inserirPassageiro(Cliente novoPassageiro) {
		int i;
		for(i = 0; i < passageiros.length && passageiros[i] != null; i++);
		passageiros[i] = novoPassageiro;
	}
	
	// Esse m�todo retorna as informa��es da viagem.
	@Override
	public String info() {
		return "\nID: " + getId() + "     Origem: " + getOrigem() + "     Destino: " + getDestino() + "     Data: " + getData() +
				"     Hor�rio: " + getHorario() + "     Pre�o: R$" + getPreco() + 
				"     Passagens Restantes: " + (getPassageiros().length - getPassagensCompradas());
	}
	
}

