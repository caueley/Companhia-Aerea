package participantes;

import javax.swing.JOptionPane;

import sistema.CompanhiaAerea;

public class Administrador extends Funcionario { 
	// M�TODO CONSTRUTOR
	public Administrador(String nomeCompleto, int diaNascimento, int mesNascimento, int anoNascimento, 
			String cpf, String usuario, String senha) {
		super(nomeCompleto, diaNascimento, mesNascimento, anoNascimento, cpf, "Administrador", usuario, senha);
		setId(-1);
	}

	/* Esse m�todo remove um cliente cadastrado. � passado ao administrador uma lista com todos os clientes atualmente cadastrados
	 * e seus respectivos IDs. O administrador, ent�o, insere o ID do cliente que deseja excluir e caso o valor passado seja v�lido, ele � removido. */
	public void removeCliente(CompanhiaAerea c) throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Clientes:\n" + c.getClientes().listarClientes() + 
				"\n\nDigite o ID do cliente que deseja remover:\n\n", "Remo��o de Cliente - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));

		int opcao = JOptionPane.showConfirmDialog(null, "Deseja mesmo remover esse cliente?", "Remo��o de Cliente", JOptionPane.YES_NO_OPTION);

		if(opcao == JOptionPane.YES_OPTION) {
			c.getClientes().removeCliente(id);
			JOptionPane.showMessageDialog(null, "Cliente removido com sucesso!", "Remo��o de Cliente - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
		}
	}

	/* Esse m�todo adiciona um novo funcion�rio � lista de funcion�rios. Ap�s a inser��o de todos os valores solicitados, caso eles sejam v�lidos, o 
	 * funcion�rio em quest�o � adicionado no sistema e � poss�vel logar no sistema utilizando suas informa��es de usu�rio e senha. */
	public void adicionaFuncionario(CompanhiaAerea c) throws Exception {
		String nome = JOptionPane.showInputDialog(null, "Digite o nome completo do funcion�rio: ", "Cadastro de Funcion�rio - " + c.getNome(), JOptionPane.QUESTION_MESSAGE);
		int dia = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o dia do nascimento do funcion�rio: ", "Cadastro de Funcion�rio - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		int mes = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o m�s do nascimento do funcion�rio: ", "Cadastro de Funcion�rio - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		int ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o ano nascimento do funcion�rio: ", "Cadastro de Funcion�rio - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));
		String cpf = JOptionPane.showInputDialog(null, "Digite o CPF do funcion�rio: ", "Cadastro de Funcion�rio - " + c.getNome(), JOptionPane.QUESTION_MESSAGE);
		String usuario = JOptionPane.showInputDialog(null, "Digite o usu�rio para acesso o sistema do funcion�rio: ", "Cadastro de Funcion�rio - " + c.getNome(), JOptionPane.QUESTION_MESSAGE);
		String senha = JOptionPane.showInputDialog(null, "Digite a senha para acesso ao sistema do funcion�rio: ", "Cadastro de Funcion�rio - " + c.getNome(), JOptionPane.QUESTION_MESSAGE);
		int cargo = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o cargo do funcion�rio: "
				+ "\n\n1. Atendente\n2. Comiss�rio\n3. Piloto\n\n", "Cadastro de Funcion�rio - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));

		Funcionario novoFuncionario = null;
		switch(cargo) {
		case 1:
			novoFuncionario = new Atendente(nome, dia, mes, ano, cpf, usuario, senha);
			break;
		case 2:
			novoFuncionario = new Comissario(nome, dia, mes, ano, cpf, usuario, senha);
			break;
		case 3:
			novoFuncionario = new Piloto(nome, dia, mes, ano, cpf, usuario, senha);
			break;
		}

		c.getFuncionarios().adicionaFuncionario(novoFuncionario);

		JOptionPane.showMessageDialog(null, "Funcion�rio cadastrado com sucesso!", "Cadastro de Funcion�rio - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
	}

	/* Esse m�todo remove um funcion�rio cadastrado. � passado ao administrador uma lista com todos os funcion�rios atualmente cadastrados e seus 
	 * respectivos IDs. O administrador, ent�o, insere o ID do funcion�rio que deseja excluir e caso o valor passado seja v�lido, ele � removido */
	public void removeFuncionario(CompanhiaAerea c) throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Funcion�rios: \n" + c.getFuncionarios().listarFuncionarios() + 
				"\n\nDigite o ID do funcion�rio que deseja remover: ", "Remo��o de Funcion�rio", 3));

		int opcao = JOptionPane.showConfirmDialog(null, "Deseja mesmo remover esse avi�o?", "Remo��o de Funcion�rio - " + c.getNome(), JOptionPane.YES_NO_OPTION);

		if(opcao == JOptionPane.YES_OPTION) {
			c.getFuncionarios().removeFuncionario(id);
			JOptionPane.showMessageDialog(null, "Funcion�rio removido com sucesso!", "Remo��o de Funcion�rio - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
		}
	}

	/* Esse m�todo adiciona um novo avi�o � lista de avi�es. Ap�s a inser��o de todos os valores solicitados, caso eles sejam v�lidos, o 
	 * avi�o em quest�o � adicionado no sistema. */
	public void adicionaAviao(CompanhiaAerea c) throws Exception {
		String modelo = JOptionPane.showInputDialog(null, "Insira o modelo do avi�o:", "Cadastro de Avi�o - " + c.getNome(), JOptionPane.QUESTION_MESSAGE);
		int capacidade = Integer.parseInt(JOptionPane.showInputDialog(null, "Insira a capacidade do avi�o: ", "Cadastro de Avi�o - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));

		Aviao novoAviao = new Aviao(modelo, capacidade);
		c.getAvioes().adicionaAviao(novoAviao);
		JOptionPane.showMessageDialog(null, "Avi�o cadastrado com sucesso!", "Cadastro de Avi�o - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
	}

	/* Esse m�todo remove um avi�o cadastrado. � passado ao administrador uma lista com todos os avi�es atualmente cadastrados e seus 
	 * respectivos IDs. O administrador, ent�o, insere o ID do avi�o que deseja excluir e caso o valor passado seja v�lido, ele � removido */
	public void removeAviao(CompanhiaAerea c) throws Exception {
		int id = Integer.parseInt(JOptionPane.showInputDialog(null, "Avi�es: \n" + c.getAvioes().listarAvioes() + 
				"\n\nDigite o ID do avi�o que deseja remover: ", "Remo��o de Avi�o - " + c.getNome(), JOptionPane.QUESTION_MESSAGE));

		int opcao = JOptionPane.showConfirmDialog(null, "Deseja mesmo remover esse avi�o?", "Remo��o de Avi�o - " + c.getNome(), JOptionPane.YES_NO_OPTION);

		if(opcao == JOptionPane.YES_OPTION) {
			c.getAvioes().removeAviao(id);
			JOptionPane.showMessageDialog(null, "Avi�o removido com sucesso!", "Remo��o de Avi�o - " + c.getNome(), JOptionPane.INFORMATION_MESSAGE);
		}
	}

}
