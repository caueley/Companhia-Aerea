package participantes;

public abstract class Funcionario extends Pessoa {
	// ATRIBUTOS
	private String cargo;
	
	// M�TODO CONSTRUTOR
	public Funcionario (String nomeCompleto, int diaNascimento, int mesNascimento, int anoNascimento, 
			String cpf, String cargo, String usuario, String senha) {
		super(nomeCompleto, diaNascimento, mesNascimento, anoNascimento, cpf, usuario, senha);
		setCargo(cargo);
	}

	// M�TODOS MODIFICADORES
	public String getCargo() {
		return cargo;
	}
	
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}	
	
	// Esse m�todo retorna as informa��es da pessoa em quest�o, como na classe Pessoa, por�m, adicionando a informa��o sobre o cargo do funcion�rio.
	@Override
	public String info() {
		return super.info() + "     Cargo: " + getCargo();
	}
}
