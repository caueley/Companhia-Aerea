package participantes;

import estrutura.AdicionaViagem;
import estrutura.ListaLigadaViagens;

public class Comissario extends Funcionario implements AdicionaViagem {
	// ATRIBUTOS
	private ListaLigadaViagens proxViagens;

	// M�TODO CONSTRUTOR
	public Comissario(String nomeCompleto, int diaNascimento, int mesNascimento, int anoNascimento, 
			String cpf, String usuario, String senha) {
		super(nomeCompleto, diaNascimento, mesNascimento, anoNascimento, cpf, "Comiss�rio", usuario, senha);
	}

	// M�TODO MODIFICADOR
	public ListaLigadaViagens getProxViagens() {
		return proxViagens;
	}

	// Esse m�todo adiciona uma viagem na lista das viagens que o comiss�rio ir� trabalhar.
	@Override
	public void adicionarViagem(Viagem v) throws Exception {
		getProxViagens().adicionaViagem(v);
	}
	
}
