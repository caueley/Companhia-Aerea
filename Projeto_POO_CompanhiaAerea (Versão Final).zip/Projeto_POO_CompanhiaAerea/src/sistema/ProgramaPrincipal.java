package sistema;

import javax.swing.JOptionPane;

import exceptions.OpcaoInvalidaException;

import banco.Banco;

public class ProgramaPrincipal {
	public static void main(String[] args) {
		CompanhiaAerea abcAirLines = new CompanhiaAerea("ABC AirLines", "12.345.678/0001-90", 3, 6, 2019, "Santo Andr�-SP");
		Banco bancoDoABC = new Banco("Banco do ABC");
		InterfaceDoSistema sistemaAbcAirLines = new InterfaceDoSistema(abcAirLines, bancoDoABC);
		
		int opcao = 0;
		do {
			try {
				opcao = sistemaAbcAirLines.telaInicial();
				switch(opcao) {
					case 1:
						sistemaAbcAirLines.telaLogin();
						break;
					case 2:
						sistemaAbcAirLines.telaCadastroNovoUsuario();
						break;
					case 3:
						sistemaAbcAirLines.telaInformacoesDaCompanhia();
						break;
					case 4:
						break;
					default:
						throw new OpcaoInvalidaException();
				}
			} catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Op��o Inv�lida", abcAirLines.getNome(), JOptionPane.ERROR_MESSAGE);
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), abcAirLines.getNome(), JOptionPane.ERROR_MESSAGE);
			} 
		} while(opcao != 4);	
	}
	
}
