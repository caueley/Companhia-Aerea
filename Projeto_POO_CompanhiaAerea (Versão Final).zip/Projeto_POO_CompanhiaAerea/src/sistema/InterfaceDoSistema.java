package sistema;

import java.text.SimpleDateFormat;

import java.util.GregorianCalendar;

import javax.swing.JOptionPane;

import exceptions.NaoCadastradoException;
import exceptions.OpcaoInvalidaException;

import participantes.Pessoa;
import participantes.Administrador;
import participantes.Cliente;
import participantes.Funcionario;
import participantes.Atendente;
import participantes.Piloto;
import participantes.Comissario;

import banco.Banco;

public class InterfaceDoSistema {
	// ATRIBUTO
	private CompanhiaAerea companhiaAerea;
	private Pessoa sessaoAtual;
	private Banco sistemaBancario;

	// M�TODO CONSTRUTOR
	public InterfaceDoSistema(CompanhiaAerea companhiaAerea, Banco sistemaBancario) {
		this.companhiaAerea = companhiaAerea;
		this.sistemaBancario = sistemaBancario;
		this.sessaoAtual = null;
	}

	// M�TODOS MODIFICADORES
	public CompanhiaAerea getCompanhiaAerea() {
		return companhiaAerea;
	}
	
	public Banco getSistemaBancario() {
		return sistemaBancario;
	}
	
	public void setSessaoAtual(Pessoa sessaoAtual) {
		this.sessaoAtual = sessaoAtual;
	}
	
	public Pessoa getSessaoAtual() {
		return sessaoAtual;
	}

	// Esse m�todo mostra a tela inicial do sistema.
	public int telaInicial() throws Exception {
		int opcao;
		opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Seja muito bem-vindo a " + companhiaAerea.getNome() + "!\n\n"
				+ "[1] Login\n[2] Novo Usu�rio\n[3] Informa��es da ABC AirLines\n[4] Encerrar Sistema\n\n", companhiaAerea.getNome(), JOptionPane.QUESTION_MESSAGE));

		if(opcao < 1 || opcao > 4) {
			throw new OpcaoInvalidaException();
		}
		return opcao;
	} 

	// Esse m�todo mostra a tela de login do sistema.
	public void telaLogin() throws Exception {
		int tipoLogin = Integer.parseInt(JOptionPane.showInputDialog(null, "Qual o tipo de acesso que deseja realizar?"
				+ "\n[1] Cliente\n[2] Funcion�rio\n[3] Voltar", companhiaAerea.getNome(), JOptionPane.QUESTION_MESSAGE));

		String usuario = null, senha = null;
		if(tipoLogin == 1 || tipoLogin == 2) {
			usuario = JOptionPane.showInputDialog(null, "Digite o usu�rio:", companhiaAerea.getNome(), JOptionPane.QUESTION_MESSAGE);
			senha = JOptionPane.showInputDialog(null, "Digite a senha:", companhiaAerea.getNome(), JOptionPane.QUESTION_MESSAGE);
		}

		switch(tipoLogin) {
		case 1:
			setSessaoAtual(companhiaAerea.verificaLogin("Cliente", usuario, senha));
			if(getSessaoAtual() != null) {
				telaCliente((Cliente) getSessaoAtual());
				setSessaoAtual(null);
			} else {
				throw new NaoCadastradoException("cliente");
			}
			break;
		case 2:
			setSessaoAtual(companhiaAerea.verificaLogin("Funcion�rio", usuario, senha));
			if(getSessaoAtual() != null) {
				telaFuncionario((Funcionario) getSessaoAtual());
				setSessaoAtual(null);
			} else {
				throw new NaoCadastradoException("funcion�rio(a)");
			}
			break;	
		case 3:
			break;
		default:
			throw new OpcaoInvalidaException();
		}
	}

	// Esse m�todo mostra a tela de cadastro de um novo cliente no sistema.
	public void telaCadastroNovoUsuario() throws Exception {
		String nome = JOptionPane.showInputDialog(null, "Digite o nome completo: ", "Cadastro de Novo Usu�rio", JOptionPane.QUESTION_MESSAGE);
		int dia = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o dia do nascimento: ", "Cadastro de Novo Usu�rio", JOptionPane.QUESTION_MESSAGE));
		int mes = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o m�s do nascimento: ", "Cadastro de Novo Usu�rio", JOptionPane.QUESTION_MESSAGE));
		int ano = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o ano nascimento: ", "Cadastro de Novo Usu�rio", JOptionPane.QUESTION_MESSAGE));
		String cpf = JOptionPane.showInputDialog(null, "Digite o CPF: ", "Cadastro de Novo Usu�rio", JOptionPane.QUESTION_MESSAGE);
		String user = JOptionPane.showInputDialog(null, "Digite o usu�rio para acesso o sistema: ", "Cadastro de Novo Usu�rio", JOptionPane.QUESTION_MESSAGE);
		String password = JOptionPane.showInputDialog(null, "Digite a senha para acesso ao sistema: ", "Cadastro de Novo Usu�rio", JOptionPane.QUESTION_MESSAGE);

		Cliente novoCliente = new Cliente(nome, dia, mes, ano, cpf, user, password);
		companhiaAerea.getClientes().adicionaCliente(novoCliente);
		setSessaoAtual(novoCliente);
		telaCliente((Cliente) getSessaoAtual());
	}

	// Esse m�todo mostra algumas informa��es sobre a companhia a�rea.
	public void telaInformacoesDaCompanhia() {
		JOptionPane.showMessageDialog(null, getCompanhiaAerea().info(), getCompanhiaAerea().getNome() + " - Informa��es", JOptionPane.INFORMATION_MESSAGE);
	}

	// Esse m�todo mostra a tela que aparece para um usu�rio do tipo cliente quando ele loga nos sistema e as funcionalidades dispon�veis para ele.
	private void telaCliente(Cliente sessaoAtual) {
		int opcao = 0;
		do {
			try {
				opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Ol�, " + sessaoAtual.getNomeCompleto() +
						"!\n\n[1] Buscar Passagem\n[2] Buscar Passagem  com Filtro\n[3] Comprar Passagem"
						+ "\n[4] Logout\n\n", getCompanhiaAerea().getNome(), JOptionPane.QUESTION_MESSAGE));

				switch(opcao) {
				case 1:
					sessaoAtual.buscarPassagem(getCompanhiaAerea());
					break;
				case 2:
					sessaoAtual.buscarPassagemAvancado(getCompanhiaAerea());
					break;
				case 3:
					sessaoAtual.compraPassagem(getCompanhiaAerea(), getSistemaBancario());
					break;
				case 4:
					int sair = JOptionPane.showConfirmDialog(null, "Deseja mesmo sair da sua conta?", "Logout", JOptionPane.YES_NO_OPTION);
					if(sair == JOptionPane.NO_OPTION) opcao = 0;
					break;
				default:
					throw new OpcaoInvalidaException();
				}
			} catch(NumberFormatException e) {
				JOptionPane.showMessageDialog(null, "Op��o Inv�lida", getCompanhiaAerea().getNome(), JOptionPane.ERROR_MESSAGE);
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage(), getCompanhiaAerea().getNome(), JOptionPane.ERROR_MESSAGE);
			}
		} while(opcao != 4);
	}

	/* Esse m�todo mostra a tela que aparece para um usu�rio do tipo funcion�rio quando ele loga nos sistema e as funcionalidades dispon�veis para ele,
	 * de acordo com o cargo dele. */
	private void telaFuncionario(Funcionario sessaoAtual) {
		if(sessaoAtual instanceof Administrador) {
			int opcao = 0;
			do {
				try {
					opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Ol�, " + sessaoAtual.getNomeCompleto() +
							"!\n\n[1] Remover Cliente\n[2] Adicionar Funcion�rio\n[3] Remover Funcion�rio\n[4] Adicionar Avi�o\n[5] Remover Avi�o"
							+ "\n[6] Logout\n\n", "Administrador - " + getCompanhiaAerea().getNome(), JOptionPane.QUESTION_MESSAGE));
					switch(opcao) {
					case 1:
						((Administrador) sessaoAtual).removeCliente(getCompanhiaAerea());
						break;
					case 2:
						((Administrador) sessaoAtual).adicionaFuncionario(getCompanhiaAerea());
						break;
					case 3:
						((Administrador) sessaoAtual).removeFuncionario(getCompanhiaAerea());
						break;
					case 4:
						((Administrador) sessaoAtual).adicionaAviao(getCompanhiaAerea());
						break;
					case 5:
						((Administrador) sessaoAtual).removeAviao(getCompanhiaAerea());
						break;
					case 6:
						int sair = JOptionPane.showConfirmDialog(null, "Deseja mesmo sair da sua conta?", "Logout - " + 
								getCompanhiaAerea().getNome(), JOptionPane.YES_NO_OPTION);
						if(sair == JOptionPane.NO_OPTION) opcao = 0;
						break;
					default:
						throw new OpcaoInvalidaException();
					}
				} catch(NumberFormatException e) {
					JOptionPane.showMessageDialog(null, "Op��o Inv�lida", "Administrador - " + getCompanhiaAerea().getNome(), JOptionPane.ERROR_MESSAGE);
				} catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Administrador - " + getCompanhiaAerea().getNome() , JOptionPane.ERROR_MESSAGE);
				}
			} while(opcao != 6);
		} else if(sessaoAtual instanceof Atendente) {
			int opcao = 0;
			do {
				try {
					opcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Ol�, " + sessaoAtual.getNomeCompleto() +
							"!\n\n[1] Adicionar Viagem\n[2] Remover Viagem\n[3] Relat�rio de Viagem" + "\n[4] Logout\n\n", 
							"Atendente - " + companhiaAerea.getNome(), JOptionPane.QUESTION_MESSAGE));
					switch(opcao) {
					case 1:
						((Atendente) sessaoAtual).adicionaViagem(getCompanhiaAerea());
						break;
					case 2:
						((Atendente) sessaoAtual).removeViagem(getCompanhiaAerea());
						break;
					case 3:
						((Atendente) sessaoAtual).relatorioDeVoo(getCompanhiaAerea());
						break;
					case 4:
						int sair = JOptionPane.showConfirmDialog(null, "Deseja mesmo sair da sua conta?", "Logout - " + 
								companhiaAerea.getNome(), JOptionPane.YES_NO_OPTION);
						if(sair == JOptionPane.NO_OPTION) opcao = 0;
						break;
					default:
						throw new OpcaoInvalidaException();
					}
				} catch(NumberFormatException e) {
					JOptionPane.showMessageDialog(null, "Op��o Inv�lida", "Atendente - " + companhiaAerea.getNome(), JOptionPane.ERROR_MESSAGE);
				} catch(Exception e) {
					JOptionPane.showMessageDialog(null, e.getMessage(), "Atendente - " + companhiaAerea.getNome(), JOptionPane.ERROR_MESSAGE);
				}
			} while(opcao != 4);
		} else if(sessaoAtual instanceof Piloto) {
			try {
				JOptionPane.showMessageDialog(null, "Ol�, " + sessaoAtual.getNomeCompleto() + "!\n\n Pr�ximas viagens:\n\n"
						+ ((Piloto) sessaoAtual).getProxViagens().listarViagens(), "Piloto - " + companhiaAerea.getNome(), JOptionPane.INFORMATION_MESSAGE);
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, "Voc� n�o possui pr�ximas viagens cadastradas no momento.", 
						"Piloto - " + companhiaAerea.getNome(), JOptionPane.INFORMATION_MESSAGE);
			}
		} else if(sessaoAtual instanceof Comissario) {
			try {
				JOptionPane.showMessageDialog(null, "Ol�, " + sessaoAtual.getNomeCompleto() + "!\n\n Pr�ximas viagens:\n\n"
						+ ((Comissario) sessaoAtual).getProxViagens().listarViagens(), "Comiss�rio - " + companhiaAerea.getNome(), JOptionPane.INFORMATION_MESSAGE);
			} catch(Exception e) {
				JOptionPane.showMessageDialog(null, "Voc� n�o possui pr�ximas viagens cadastradas no momento.", 
						"Comiss�rio - " + companhiaAerea.getNome(), JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}

	// Esse m�todo retorna uma data padronizada, dado os par�metros passados � ele.
	public static String formatarData(int dia, int mes, int ano) {
		GregorianCalendar data = new GregorianCalendar(ano, mes, dia);
		SimpleDateFormat dataFormatada = new SimpleDateFormat("dd/MM/yyyy");
		return dataFormatada.format(data.getTime());
	}
	// Esse m�todo retorna um hor�rio padronizado, dado os par�metros passados � ele.
	public static String formatarHorario(int dia, int mes, int ano, int hora, int minuto) {
		GregorianCalendar dataEHorario = new GregorianCalendar(ano, mes, dia, hora, minuto);
		SimpleDateFormat horarioFormatado = new SimpleDateFormat("HH:mm");
		return horarioFormatado.format(dataEHorario.getTime());
	}

}
