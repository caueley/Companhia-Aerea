
package sistema;

import javax.swing.JOptionPane;

import estrutura.Informacoes;
import estrutura.ListaLigadaAviao;
import estrutura.ListaLigadaCliente;
import estrutura.ListaLigadaViagens;
import estrutura.ListaLigadaFuncionario;

import participantes.Pessoa;
import participantes.Administrador;
import participantes.Cliente;
import participantes.Atendente;
import participantes.Piloto;
import participantes.Comissario;
import participantes.Aviao;
import participantes.Viagem;

public class CompanhiaAerea implements Informacoes {
	// ATRIBUTOS
	private String nome;
	private String cnpj;
	private String fundacao;
	private String localizacao;
	private ListaLigadaCliente clientes;
	private ListaLigadaFuncionario funcionarios;
	private ListaLigadaAviao avioes;
	private ListaLigadaViagens viagens;

	// M�TODO CONSTRUTOR
	public CompanhiaAerea(String nome, String cnpj, int fundacaoDia, int fundacaoMes, int fundacaoAno, String localizacao) {
		this.nome = nome;
		this.cnpj = cnpj;
		this.fundacao = InterfaceDoSistema.formatarData(fundacaoDia, fundacaoMes, fundacaoAno);
		this.localizacao = localizacao;

		clientes = new ListaLigadaCliente();
		funcionarios = new ListaLigadaFuncionario();
		avioes  = new ListaLigadaAviao();
		viagens = new ListaLigadaViagens();

		try {
			// Deixei alguns objetos cadastrados para que n�o seja necess�rio cadastrar manualmente cada vez que o programa � executado.
			
			// Administrador Cadastrado
			funcionarios.adicionaFuncionario(new Administrador("Jo�o Pedro", 11, 12, 1996, "470.230.718-57", "joao.pereira", "adm123"));

			// Clientes Cadastrados
			clientes.adicionaCliente(new Cliente("Carlos dos Santos", 14, 2, 1972, "123.456.789-01", "carlos.santos", "123"));
			clientes.adicionaCliente(new Cliente("Rebeca Andrade", 22, 4, 1996, "123.456.789-02", "rebeca.andrade", "123"));
			clientes.adicionaCliente(new Cliente("Vin�cius Teixeira", 1, 9, 1982, "123.456.789-03", "vinicius.teixeira", "123"));
			clientes.adicionaCliente(new Cliente("Antonio Carlos Macedo", 22, 10, 1977, "123.456.789-04", "antonio.macedo", "123"));
			clientes.adicionaCliente(new Cliente("Giovanna Garc�a", 17, 8, 1994, "123.456.789-05", "giovanna.garcia", "123"));
			clientes.adicionaCliente(new Cliente("Lucas Matos", 20, 11, 1997, "123.456.789-06", "lucas.matos", "123"));
			clientes.adicionaCliente(new Cliente("Lu�sa Garc�a", 20, 11, 1998, "123.456.789-07", "luisa.garcia", "123"));
			clientes.adicionaCliente(new Cliente("Guilherme da Silva", 2, 4, 1996, "123.456.789-08", "guilherme.silva", "123"));
			clientes.adicionaCliente(new Cliente("Giuliana Pereira", 6, 7, 1988, "123.456.789-09", "giuliana.pereira", "123"));
			clientes.adicionaCliente(new Cliente("J�lia Neves", 3, 4, 1959, "123.456.789-10", "julia.neves", "123"));


			// Funcion�rios Cadastrados
			funcionarios.adicionaFuncionario(new Atendente("V�nia Matos", 1, 7, 1990, "123.456.789-11","vania.matos", "123"));
			funcionarios.adicionaFuncionario(new Atendente("Euclides Monteiro", 18, 4, 1988, "123.456.789-12", "euclides.monteiro", "123"));
			funcionarios.adicionaFuncionario(new Atendente("Saulo Castro", 23, 2, 1978, "123.456.789-13", "saulo.castro", "123"));
			funcionarios.adicionaFuncionario(new Atendente("Gabriel Arruda", 4, 4, 1985, "123.456.789-14", "gabriel.arruda", "123"));
			funcionarios.adicionaFuncionario(new Atendente("Bruna Garc�a", 14, 3, 1990, "123.456.789-15", "bruna.garcia", "123"));

			Piloto piloto1 = new Piloto("Ricardo Abreu", 20, 5, 1977, "123.456.789-16", "ricardo.abreu", "123");
			funcionarios.adicionaFuncionario(piloto1);
			Piloto piloto2 = new Piloto("Fl�via Monteiro", 11, 11, 1980, "123.456.789-17", "flavia.monteiro", "123");
			funcionarios.adicionaFuncionario(piloto2);
			Piloto piloto3 = new Piloto("Gustavo Takashi", 20, 1, 1979, "123.456.789-18", "gustavo.takashi", "123");
			funcionarios.adicionaFuncionario(piloto3);
			Piloto piloto4 = new Piloto("Valter J�nior", 14, 3, 1982, "123.456.789-19", "valter.junior", "123");
			funcionarios.adicionaFuncionario(piloto4);
			Piloto piloto5 = new Piloto("Maria Clara dos Santos", 29, 12, 1975, "123.456.789-20", "maria.santos", "123");
			funcionarios.adicionaFuncionario(piloto5);

			Comissario comissario1 = new Comissario("D�bora Nascimento", 20, 1, 1985, "123.456.789-21", "debora.nascimento", "123");
			funcionarios.adicionaFuncionario(comissario1);
			Comissario comissario2 = new Comissario("Henrique Monteiro", 14, 3, 1990, "123.456.789-22", "henrique.monteiro", "123");
			funcionarios.adicionaFuncionario(comissario2);
			Comissario comissario3 = new Comissario("G�rson Freitas", 27, 11, 1988, "123.456.789-23", "gerson.freitas", "123");
			funcionarios.adicionaFuncionario(comissario3);
			Comissario comissario4 = new Comissario("Talita Freitas", 18, 3, 1980, "123.456.789-24", "talita.freitas", "123");
			funcionarios.adicionaFuncionario(comissario4);
			Comissario comissario5 = new Comissario("Chiara Bueno", 7, 5, 1988, "123.456.789-25", "chiara.bueno", "123");
			funcionarios.adicionaFuncionario(comissario5);

			// Avi�es Cadastrados
			Aviao aviao1 = new Aviao("Airbus", 150);
			avioes.adicionaAviao(aviao1);
			Aviao aviao2 = new Aviao("Airbus", 120);
			avioes.adicionaAviao(aviao2);
			Aviao aviao3 = new Aviao("Airbus", 120);
			avioes.adicionaAviao(aviao3);
			Aviao aviao4 = new Aviao("Boeing", 300);
			avioes.adicionaAviao(aviao4);
			Aviao aviao5 = new Aviao("Boeing", 300);
			avioes.adicionaAviao(aviao5);

			// Viagens Cadastradas
			Viagem viagem1 = new Viagem("S�o Paulo", "Rio de Janeiro", 20, 9, 2019, 19, 30, 500, aviao1, piloto1, piloto2, comissario1, comissario2);
			viagens.adicionaViagem(viagem1);
			Viagem viagem2 = new Viagem("S�o Paulo", "Cuiab�", 14, 8, 2019, 23, 00, 900, aviao2, piloto3, piloto4, comissario3, comissario4);
			viagens.adicionaViagem(viagem2);
			Viagem viagem3 = new Viagem("S�o Paulo", "Nova York", 30, 8, 2019, 0, 30, 1800, aviao3, piloto5, piloto1, comissario5, comissario1);
			viagens.adicionaViagem(viagem3);
			Viagem viagem4 = new Viagem("S�o Paulo", "Austr�lia", 25, 10, 2019, 22, 0, 2500, aviao4, piloto2, piloto3, comissario2, comissario3);
			viagens.adicionaViagem(viagem4);
			Viagem viagem5 = new Viagem("S�o Paulo", "Manaus", 1, 12, 2019, 20, 0, 1000, aviao5, piloto4, piloto5, comissario4, comissario5);
			viagens.adicionaViagem(viagem5);	 
		} catch(Exception e) {
			JOptionPane.showMessageDialog(null, e.getMessage());
		}
	}

	// M�TODOS MODIFICADORES
	public String getNome() {
		return nome;
	}

	public String getCnpj() {
		return cnpj;
	}

	public String getFundacao() {
		return fundacao;
	}

	public String getLocalizacao() {
		return localizacao;
	}

	public ListaLigadaCliente getClientes() {
		return clientes;
	}

	public ListaLigadaFuncionario getFuncionarios() {
		return funcionarios;
	}

	public ListaLigadaAviao getAvioes() {
		return avioes;
	}

	public ListaLigadaViagens getViagens() {
		return viagens;
	}

	// Esse m�todo retorna as informa��es da companhia a�rea.
	@Override
	public String info() {
		return "Nome da Companhia: " + getNome() + "\nCNPJ: " + getCnpj() + 
				"\nFunda��o: " + getFundacao() + "\nLocaliza��o: " + getLocalizacao() + 
				"\nN� de Funcion�rios: " + (funcionarios.tamanhoDaLista()-1) + "\nN� de Avi�es: " + avioes.tamanhoDaLista() 
				+ "\nN� de Clientes: " + clientes.tamanhoDaLista();
	}

	// Esse m�todo verifica se a pessoa que esta tentando acessar o sistema utilizou um usuario e senha que estejam cadastrados no sistema.
	public Pessoa verificaLogin(String tipo, String usuario, String senha) {
		if(tipo.equals("Cliente")) {
			return clientes.verificaLogin(usuario, senha);
		} else {
			return funcionarios.verificaLogin(usuario, senha);
		}
	}

}
